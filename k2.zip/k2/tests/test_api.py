import json

def test_api_health(client):
    res = client.get("/api/health")
    assert res.status_code == 200
    data = res.get_json()
    assert data["status"] == "healthy"
    assert "BACKKBENCHERS" in data["service"]

def test_api_dashboard(client):
    res = client.get("/api/dashboard?client_id=1&days=30")
    assert res.status_code == 200
    data = res.get_json()
    assert data["success"] is True
    assert "ai_health_score" in data["data"]

def test_api_ai_chat(client):
    res = client.post("/api/ai/chat", json={
        "client_id": 1,
        "message": "What is our best performing social platform?"
    })
    assert res.status_code == 200
    data = res.get_json()
    assert data["success"] is True
    assert "reply" in data["data"]

def test_api_lead_ingestion(client):
    res = client.post("/api/leads", json={
        "client_id": 1,
        "first_name": "Siddharth",
        "last_name": "Roy",
        "email": "sid@apexsupps.com",
        "phone": "+91 99999 88888",
        "company": "Apex Supplements",
        "source": "Meta Lead Form"
    })
    assert res.status_code == 201
    data = res.get_json()
    assert data["success"] is True
    assert data["lead_id"] is not None
    assert "ai_score" in data

