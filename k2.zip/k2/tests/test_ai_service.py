from app.services.ai_service import AIService
from app.models.ai import AIConversation, AIMessage, ActionStatus

def test_ai_agent_chat_and_action_trigger(app):
    with app.app_context():
        # Test chat with schedule trigger
        result = AIService.chat_with_agent(
            client_id=1,
            user_id=2,
            user_message="Create a social media campaign for our apparel line and schedule posts"
        )
        assert result["conversation_id"] is not None
        assert result["reply"] is not None
        assert result["action_required"] is True
        assert result["action_type"] == "SCHEDULE_POSTS"
        assert len(result["action_payload"]["posts"]) == 3

        # Test action execution confirmation
        exec_res = AIService.execute_confirmed_action(result["message_id"], user_id=2)
        assert exec_res["success"] is True

        # Verify message status updated
        msg = app.extensions["sqlalchemy"].session.get(AIMessage, result["message_id"])
        assert msg.action_status == ActionStatus.CONFIRMED

def test_ai_content_generators(app):
    with app.app_context():
        caption = AIService.generate_content(
            client_id=1,
            prompt="Monsoon waterproof gym drop",
            content_type="Caption",
            platform="Instagram",
            tone="Bold",
            audience="Lifters"
        )
        assert "AeroFit" in caption or "Brand" in caption
        assert "#" in caption

