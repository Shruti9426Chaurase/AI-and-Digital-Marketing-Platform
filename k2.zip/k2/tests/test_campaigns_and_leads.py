from datetime import date
from app.services.campaign_service import CampaignService
from app.services.lead_service import LeadService
from app.models.lead import LeadStatus, LeadScore, Customer

def test_campaign_wizard_creation(app):
    with app.app_context():
        c = CampaignService.create_campaign(
            client_id=1,
            name="Diwali Mega Viral Drop",
            objective="Sales",
            budget=200000.0,
            target_audience="Gym enthusiasts",
            platforms=["Instagram", "Meta Ads"]
        )
        assert c.id is not None
        assert c.name == "Diwali Mega Viral Drop"
        assert c.budget == 200000.0

def test_lead_crm_and_scoring(app):
    with app.app_context():
        lead = LeadService.create_lead(
            client_id=1,
            first_name="Rajesh",
            last_name="Khanna",
            email="rajesh@fitnessgym.com",
            phone="+91 98999 11223",
            company="Fitness Gym Chain",
            source="Website Contact Form"
        )
        assert lead.id is not None
        assert lead.ai_score in [LeadScore.HOT, LeadScore.WARM]
        assert lead.status == LeadStatus.NEW

        # Test conversion to Customer
        LeadService.update_lead_status(lead.id, LeadStatus.CONVERTED)
        assert lead.status == LeadStatus.CONVERTED
        customer = Customer.query.filter_by(lead_id=lead.id).first()
        assert customer is not None
        assert customer.lifetime_value > 0

