from datetime import date
from app.extensions import db
from app.models.campaign import CampaignMetric
from app.services.analytics_service import AnalyticsService

def test_metric_properties_and_roas(app):
    with app.app_context():
        m = CampaignMetric(
            client_id=1,
            date=date.today(),
            platform="Meta Ads",
            data_source="MANUAL",
            impressions=10000,
            reach=8000,
            clicks=500,
            conversions=25,
            spend=5000.0,
            revenue=25000.0,
            likes=300,
            comments=40,
            shares=20
        )
        db.session.add(m)
        db.session.commit()

        assert m.ctr == 5.0      # 500 / 10000 * 100
        assert m.cpc == 10.0     # 5000 / 500
        assert m.cpa == 200.0    # 5000 / 25
        assert m.roas == 5.0     # 25000 / 5000
        assert m.roi == 400.0    # (25000 - 5000) / 5000 * 100
        assert m.engagement_rate == 4.5  # (300 + 40 + 20) / 8000 * 100

def test_dashboard_overview_aggregation(app):
    with app.app_context():
        overview = AnalyticsService.get_dashboard_overview(client_id=1, days=30)
        assert "ai_health_score" in overview
        assert overview["ai_health_score"] > 50
        assert "roas" in overview

