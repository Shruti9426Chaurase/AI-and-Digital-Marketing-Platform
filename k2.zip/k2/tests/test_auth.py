from app.models.user import User, UserRole

def test_user_password_hashing(app):
    with app.app_context():
        user = User(email="testuser@example.com", first_name="Test", last_name="User")
        user.set_password("SecurePass123!")
        assert user.password_hash is not None
        assert user.check_password("SecurePass123!") is True
        assert user.check_password("WrongPassword") is False

def test_login_and_logout(client):
    # Test valid login
    res = client.post("/auth/login", data={
        "email": "client@test.com",
        "password": "Client@1234"
    }, follow_redirects=True)
    assert res.status_code == 200
    assert b"Welcome back, Client!" in res.data or b"Dashboard" in res.data

    # Test logout
    logout_res = client.get("/auth/logout", follow_redirects=True)
    assert logout_res.status_code == 200
    assert b"logged out" in logout_res.data or b"Turn Your Brand" in logout_res.data

def test_role_access_control(client):
    # Unauthenticated access to dashboard should redirect to login
    res = client.get("/dashboard/", follow_redirects=False)
    assert res.status_code == 302
    assert "/auth/login" in res.headers["Location"]

