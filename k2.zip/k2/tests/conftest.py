import pytest
from app import create_app
from app.extensions import db
from app.models.user import User, UserRole
from app.models.client import Client, BrandKit

@pytest.fixture
def app():
    app = create_app("testing")
    with app.app_context():
        db.create_all()
        # Seed test admin & client
        admin = User(
            email="admin@test.com",
            first_name="Admin",
            last_name="Test",
            role=UserRole.ADMIN,
            is_active=True,
            is_verified=True
        )
        admin.set_password("Admin@1234")
        db.session.add(admin)

        client_user = User(
            email="client@test.com",
            first_name="Client",
            last_name="Test",
            role=UserRole.CLIENT,
            is_active=True,
            is_verified=True
        )
        client_user.set_password("Client@1234")
        db.session.add(client_user)
        db.session.flush()

        client = Client(
            user_id=client_user.id,
            company_name="AeroFit Test Brand",
            industry="Apparel",
            tier="Growth",
            status="Active"
        )
        db.session.add(client)
        db.session.flush()

        brand_kit = BrandKit(
            client_id=client.id,
            brand_name=client.company_name,
            tagline="Test Tagline",
            primary_color="#FFC72C",
            secondary_color="#EF4444"
        )
        db.session.add(brand_kit)
        db.session.commit()

        yield app

        db.session.remove()
        db.drop_all()

@pytest.fixture
def client(app):
    return app.test_client()

@pytest.fixture
def runner(app):
    return app.test_cli_runner()

