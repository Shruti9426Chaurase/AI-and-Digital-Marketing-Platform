from datetime import datetime, timezone
from flask import Blueprint, render_template, redirect, url_for, flash, request, current_app
from flask_login import login_user, logout_user, login_required, current_user
from app.extensions import db
from app.models.user import User, UserRole
from app.models.client import Client, BrandKit
from app.auth.forms import (
    LoginForm, RegisterForm, ForgotPasswordForm, ResetPasswordForm,
    ProfileForm, ChangePasswordForm
)
from app.auth.security import log_audit_action, get_current_client

auth_bp = Blueprint("auth", __name__, url_prefix="/auth")


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        if current_user.is_admin:
            return redirect(url_for("admin.dashboard"))
        return redirect(url_for("client.dashboard"))

    form = LoginForm()
    if form.validate_on_submit():
        email = form.email.data.strip().lower()
        password = form.password.data

        user = User.query.filter_by(email=email).first()
        if user and user.check_password(password):
            if not user.is_active:
                flash("This account has been deactivated. Please contact support.", "danger")
                return render_template("auth/login.html", form=form)

            user.last_login_at = datetime.now(timezone.utc)
            db.session.commit()

            login_user(user, remember=form.remember_me.data)
            log_audit_action("USER_LOGIN", f"User {user.email} logged in successfully")
            flash(f"Welcome back, {user.first_name}!", "success")

            next_page = request.args.get("next")
            if next_page and next_page.startswith("/"):
                return redirect(next_page)

            if user.is_admin:
                return redirect(url_for("admin.dashboard"))
            return redirect(url_for("client.dashboard"))
        else:
            flash("Invalid email or password. Please check your credentials.", "danger")

    return render_template("auth/login.html", form=form)


@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("client.dashboard"))

    form = RegisterForm()
    if form.validate_on_submit():
        email = form.email.data.strip().lower()

        # 1. Create User
        user = User(
            email=email,
            first_name=form.first_name.data.strip(),
            last_name=form.last_name.data.strip() if form.last_name.data else "",
            role=UserRole.CLIENT,
            is_active=True,
            is_verified=True,
            last_login_at=datetime.now(timezone.utc)
        )
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.flush()

        # 2. Create Client Workspace
        client = Client(
            user_id=user.id,
            company_name=form.company_name.data.strip(),
            industry="Digital Marketing",
            phone=form.phone.data.strip() if form.phone.data else None,
            tier="Growth",
            status="Active"
        )
        db.session.add(client)
        db.session.flush()

        # 3. Create BrandKit
        brand_kit = BrandKit(
            client_id=client.id,
            brand_name=client.company_name,
            tagline="Engineered for Peak Performance",
            target_audience="Modern Digital Consumers",
            primary_color="#FFC72C",
            secondary_color="#EF4444"
        )
        db.session.add(brand_kit)
        db.session.commit()

        login_user(user)
        log_audit_action("USER_REGISTER", f"New workspace registered for {user.email} ({client.company_name})")
        flash(f"Welcome to BackkBenchers! Workspace '{client.company_name}' is ready.", "success")
        return redirect(url_for("client.dashboard"))

    return render_template("auth/register.html", form=form)


@auth_bp.route("/logout")
@login_required
def logout():
    log_audit_action("USER_LOGOUT", f"User {current_user.email} logged out")
    logout_user()
    flash("You have been safely logged out.", "info")
    return redirect(url_for("public.home"))


@auth_bp.route("/forgot-password", methods=["GET", "POST"])
def forgot_password():
    form = ForgotPasswordForm()
    if form.validate_on_submit():
        email = form.email.data.strip().lower()
        user = User.query.filter_by(email=email).first()
        if user:
            log_audit_action("PASSWORD_RESET_REQUEST", f"Reset requested for {email}")
        # Always flash positive message to prevent user enumeration
        flash("If that email is registered, password reset instructions have been sent.", "info")
        return redirect(url_for("auth.login"))

    return render_template("auth/forgot_password.html", form=form)


@auth_bp.route("/reset-password/<token>", methods=["GET", "POST"])
def reset_password(token):
    form = ResetPasswordForm()
    if form.validate_on_submit():
        flash("Password has been reset successfully. Please sign in.", "success")
        return redirect(url_for("auth.login"))
    return render_template("auth/reset_password.html", form=form)


@auth_bp.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    profile_form = ProfileForm()
    password_form = ChangePasswordForm()
    client = get_current_client()

    if request.method == "POST":
        if "submit_password" in request.form:
            if password_form.validate_on_submit():
                if current_user.check_password(password_form.current_password.data):
                    current_user.set_password(password_form.new_password.data)
                    db.session.commit()
                    log_audit_action("PASSWORD_CHANGED", f"User {current_user.email} updated their password")
                    flash("Your password has been changed successfully.", "success")
                    return redirect(url_for("auth.profile"))
                else:
                    flash("Incorrect current password.", "danger")
        else:
            if profile_form.validate_on_submit():
                current_user.first_name = profile_form.first_name.data.strip()
                current_user.last_name = profile_form.last_name.data.strip()
                if client:
                    client.company_name = profile_form.company_name.data.strip()
                    client.phone = profile_form.phone.data.strip()
                    client.website = profile_form.website.data.strip()
                db.session.commit()
                log_audit_action("PROFILE_UPDATED", f"User {current_user.email} updated their profile")
                flash("Your profile information has been saved.", "success")
                return redirect(url_for("auth.profile"))

    if request.method == "GET":
        profile_form.first_name.data = current_user.first_name
        profile_form.last_name.data = current_user.last_name
        if client:
            profile_form.company_name.data = client.company_name
            profile_form.phone.data = client.phone
            profile_form.website.data = client.website

    return render_template(
        "auth/profile.html",
        profile_form=profile_form,
        password_form=password_form,
        client=client
    )

