from datetime import datetime, timezone, date
from flask import Blueprint, jsonify, request
from app.extensions import db, csrf
from app.models.user import User, UserRole
from app.models.client import Client
from app.models.campaign import Campaign, CampaignMetric
from app.models.social import SocialAccount, SocialPost, PostStatus
from app.models.lead import Lead
from app.models.seo import SEOProject
from app.models.report import Report, ReportType
from app.services.ai_service import AIService
from app.services.analytics_service import AnalyticsService
from app.services.social_service import SocialService
from app.services.lead_service import LeadService
from app.services.report_service import ReportService
from app.services.seo_service import SEOService

api_bp = Blueprint("api", __name__, url_prefix="/api")


@api_bp.route("/health", methods=["GET"])
def health_check():
    """Health check endpoint for Render / Railway / AWS / Docker container probes."""
    return jsonify({
        "status": "healthy",
        "service": "BACKKBENCHERS AI Marketing Engine",
        "version": "2.0.0",
        "timestamp": datetime.now(timezone.utc).isoformat()
    })


@api_bp.route("/dashboard", methods=["GET"])
def get_dashboard_metrics():
    """GET /api/dashboard - Returns overview KPIs for the current client."""
    client_id = request.args.get("client_id", 1, type=int)
    days = request.args.get("days", 30, type=int)
    overview = AnalyticsService.get_dashboard_overview(client_id, days=days)
    return jsonify({"success": True, "data": overview})


@api_bp.route("/social/accounts", methods=["GET"])
def get_social_accounts():
    """GET /api/social/accounts - Returns connected social accounts."""
    client_id = request.args.get("client_id", 1, type=int)
    accounts = SocialAccount.query.filter_by(client_id=client_id).all()
    data = [
        {
            "id": a.id,
            "platform": a.platform,
            "handle": a.account_handle,
            "followers": a.follower_count,
            "is_connected": a.is_connected,
            "engagement_rate": a.engagement_rate
        }
        for a in accounts
    ]
    return jsonify({"success": True, "accounts": data})


@api_bp.route("/social/posts", methods=["GET", "POST"])
@csrf.exempt
def handle_social_posts():
    """GET or POST /api/social/posts - Fetch or create social post."""
    client_id = request.args.get("client_id", 1, type=int)

    if request.method == "POST":
        body = request.get_json() or {}
        post = SocialService.create_or_schedule_post(
            client_id=client_id,
            platform=body.get("platform", "INSTAGRAM"),
            content=body.get("content", ""),
            hashtags=body.get("hashtags", ""),
            media_url=body.get("media_url")
        )
        return jsonify({"success": True, "post_id": post.id, "status": post.status}), 201

    posts = SocialPost.query.filter_by(client_id=client_id).order_by(SocialPost.created_at.desc()).limit(50).all()
    data = [
        {
            "id": p.id,
            "platform": p.platform,
            "content": p.content_text,
            "status": p.status,
            "reach": p.performance_reach,
            "likes": p.performance_likes
        }
        for p in posts
    ]
    return jsonify({"success": True, "posts": data})


@api_bp.route("/campaigns", methods=["GET", "POST"])
@csrf.exempt
def handle_campaigns():
    """GET or POST /api/campaigns - List or create marketing campaigns."""
    client_id = request.args.get("client_id", 1, type=int)

    if request.method == "POST":
        body = request.get_json() or {}
        camp = Campaign(
            client_id=client_id,
            name=body.get("name", "Untitled API Campaign"),
            objective=body.get("objective", "Sales"),
            budget=float(body.get("budget", 50000)),
            spend=0.0,
            target_audience_desc=body.get("target_audience"),
            platforms_json=body.get("platforms", ["Instagram"]),
            status="ACTIVE"
        )
        db.session.add(camp)
        db.session.commit()
        return jsonify({"success": True, "campaign_id": camp.id}), 201

    campaigns = Campaign.query.filter_by(client_id=client_id).all()
    data = [
        {
            "id": c.id,
            "name": c.name,
            "objective": c.objective,
            "status": c.status,
            "budget": c.budget,
            "spend": c.spend
        }
        for c in campaigns
    ]
    return jsonify({"success": True, "campaigns": data})


@api_bp.route("/ai/chat", methods=["POST"])
@csrf.exempt
def ai_chat_endpoint():
    """POST /api/ai/chat - Direct conversational prompt to the AI Marketing Agent."""
    body = request.get_json() or {}
    user_msg = body.get("message", "")
    client_id = body.get("client_id", 1)
    conv_id = body.get("conversation_id")

    res = AIService.chat_with_agent(client_id, user_id=1, user_message=user_msg, conversation_id=conv_id)
    return jsonify({"success": True, "data": res})


@api_bp.route("/ai/generate-content", methods=["POST"])
@csrf.exempt
def ai_generate_content_endpoint():
    """POST /api/ai/generate-content - Generates marketing copy via AI."""
    body = request.get_json() or {}
    client_id = body.get("client_id", 1)
    prompt = body.get("prompt", "")
    content_type = body.get("content_type", "Caption")
    platform = body.get("platform", "Instagram")
    tone = body.get("tone", "Bold")
    audience = body.get("audience", "General")

    text = AIService.generate_content(client_id, prompt, content_type, platform, tone, audience)
    return jsonify({"success": True, "generated_content": text})


@api_bp.route("/leads", methods=["GET", "POST"])
@csrf.exempt
def handle_leads():
    """GET or POST /api/leads - Lead pipeline ingestion and retrieval."""
    client_id = request.args.get("client_id", 1, type=int)

    if request.method == "POST":
        body = request.get_json() or {}
        lead = LeadService.create_lead(
            client_id=client_id,
            first_name=body.get("first_name", "Prospect"),
            last_name=body.get("last_name", ""),
            email=body.get("email", ""),
            phone=body.get("phone"),
            company=body.get("company"),
            source=body.get("source", "API Ingestion"),
            notes=body.get("notes")
        )
        return jsonify({
            "success": True,
            "lead_id": lead.id,
            "ai_score": lead.ai_score,
            "score_value": lead.score_value
        }), 201

    leads = Lead.query.filter_by(client_id=client_id).all()
    data = [
        {
            "id": l.id,
            "name": l.full_name,
            "email": l.email,
            "company": l.company,
            "score": l.ai_score,
            "status": l.status
        }
        for l in leads
    ]
    return jsonify({"success": True, "leads": data})


@api_bp.route("/seo", methods=["GET"])
def get_seo_data():
    """GET /api/seo - SEO health and keyword rankings."""
    client_id = request.args.get("client_id", 1, type=int)
    proj = SEOProject.query.filter_by(client_id=client_id).first()
    if not proj:
        proj = SEOService.get_or_create_project(client_id)

    keywords = [
        {"keyword": k.keyword, "rank": k.current_rank, "volume": k.search_volume}
        for k in proj.keywords.all()
    ]
    return jsonify({
        "success": True,
        "health_score": proj.health_score,
        "technical_score": proj.technical_score,
        "keywords": keywords
    })


@api_bp.route("/reports", methods=["GET", "POST"])
@csrf.exempt
def handle_reports():
    """GET or POST /api/reports - Automated reports list or generation."""
    client_id = request.args.get("client_id", 1, type=int)

    if request.method == "POST":
        body = request.get_json() or {}
        rep_type = body.get("report_type", ReportType.WEEKLY)
        rep = ReportService.generate_report(client_id, report_type=rep_type)
        return jsonify({"success": True, "report_id": rep.id, "title": rep.title}), 201

    reports = Report.query.filter_by(client_id=client_id).order_by(Report.created_at.desc()).all()
    data = [
        {
            "id": r.id,
            "title": r.title,
            "type": r.report_type,
            "period": f"{r.period_start} to {r.period_end}"
        }
        for r in reports
    ]
    return jsonify({"success": True, "reports": data})

