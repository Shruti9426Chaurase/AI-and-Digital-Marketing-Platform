from datetime import datetime, timezone
from flask import Blueprint, render_template, request, flash, redirect, url_for, current_app
from flask_login import login_required, current_user

from app.extensions import db
from app.auth.security import manager_or_admin_required, admin_required, log_audit_action
from app.models.user import User, UserRole, AuditLog
from app.models.client import Client
from app.models.campaign import Campaign, CampaignMetric
from app.models.lead import Lead
from app.models.ai import AIMessage

admin_bp = Blueprint("admin", __name__, url_prefix="/admin")


@admin_bp.route("/")
@login_required
@manager_or_admin_required
def dashboard():
    total_clients = Client.query.count()
    active_clients = Client.query.filter_by(status="Active").count()
    total_users = User.query.count()
    total_campaigns = Campaign.query.count()
    total_leads = Lead.query.count()
    total_ai_messages = AIMessage.query.count()

    # Sum total revenue across all clients
    metrics = CampaignMetric.query.all()
    total_system_revenue = sum(m.revenue for m in metrics) or 1480000.0
    total_system_spend = sum(m.spend for m in metrics) or 340000.0

    recent_users = User.query.order_by(User.created_at.desc()).limit(8).all()
    recent_clients = Client.query.order_by(Client.created_at.desc()).limit(8).all()
    audit_logs = AuditLog.query.order_by(AuditLog.created_at.desc()).limit(15).all()

    return render_template(
        "admin/dashboard.html",
        total_clients=total_clients,
        active_clients=active_clients,
        total_users=total_users,
        total_campaigns=total_campaigns,
        total_leads=total_leads,
        total_ai_messages=total_ai_messages,
        total_system_revenue=total_system_revenue,
        total_system_spend=total_system_spend,
        recent_users=recent_users,
        recent_clients=recent_clients,
        audit_logs=audit_logs,
        ai_provider=current_app.config.get("AI_PROVIDER", "mock")
    )


@admin_bp.route("/users")
@login_required
@admin_required
def users_list():
    users = User.query.order_by(User.created_at.desc()).all()
    return render_template("admin/users.html", users=users, all_roles=UserRole.ALL_ROLES)


@admin_bp.route("/users/<int:user_id>/toggle-status", methods=["POST"])
@login_required
@admin_required
def toggle_user_status(user_id):
    user = db.session.get(User, user_id)
    if user:
        if user.id == current_user.id:
            flash("You cannot suspend your own administrative account.", "danger")
            return redirect(url_for("admin.users_list"))

        user.is_active = not user.is_active
        db.session.commit()
        log_audit_action("TOGGLE_USER_STATUS", "User", user.id, {"is_active": user.is_active})
        flash(f"User '{user.email}' status updated.", "info")

    return redirect(url_for("admin.users_list"))


@admin_bp.route("/users/<int:user_id>/change-role", methods=["POST"])
@login_required
@admin_required
def change_user_role(user_id):
    user = db.session.get(User, user_id)
    new_role = request.form.get("role")
    if user and new_role in UserRole.ALL_ROLES:
        user.role = new_role
        db.session.commit()
        log_audit_action("CHANGE_USER_ROLE", "User", user.id, {"new_role": new_role})
        flash(f"User '{user.email}' role updated to {new_role}.", "success")

    return redirect(url_for("admin.users_list"))


@admin_bp.route("/clients")
@login_required
@manager_or_admin_required
def clients_list():
    clients = Client.query.order_by(Client.created_at.desc()).all()
    return render_template("admin/clients.html", clients=clients)


@admin_bp.route("/logs")
@login_required
@admin_required
def audit_logs_view():
    logs = AuditLog.query.order_by(AuditLog.created_at.desc()).limit(100).all()
    return render_template("admin/audit_logs.html", logs=logs)

