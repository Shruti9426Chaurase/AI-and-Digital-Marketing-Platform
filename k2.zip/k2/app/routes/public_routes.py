from flask import Blueprint, render_template, request, flash, redirect, url_for
from app.extensions import db
from app.models.lead import Lead, LeadStatus, LeadScore
from app.models.system import Notification
from app.models.client import Client

public_bp = Blueprint("public", __name__)

SERVICES_LIST = [
    {
        "id": "social-media",
        "title": "Social Media Management",
        "category": "Social & Viral",
        "icon": "fa-share-nodes",
        "desc": "End-to-end multi-platform content scheduling, community management, viral hooks, and follower growth loops across Instagram, Facebook, LinkedIn, X, and YouTube."
    },
    {
        "id": "hoardings-billboards",
        "title": "Hoardings & Billboards",
        "category": "Outdoor & OOH",
        "icon": "fa-signs-post",
        "desc": "Prime high-footfall billboard placements, eye-catching highway unipoles, and high-impact digital LED screens that capture immediate mass attention."
    },
    {
        "id": "metro-pillars",
        "title": "Metro Pillars Advertising",
        "category": "Outdoor & OOH",
        "icon": "fa-train-subway",
        "desc": "Continuous high-frequency exposure across busy transit lines, turning daily commuter routes into your brand's personal runway."
    },
    {
        "id": "transit-advertising",
        "title": "Transit Advertising",
        "category": "Outdoor & OOH",
        "icon": "fa-bus",
        "desc": "Full bus wraps, auto hoods, cab branding, and airport transit media that take your marketing directly to every neighborhood in the city."
    },
    {
        "id": "ai-marketing",
        "title": "AI Marketing Automation",
        "category": "AI & Automation",
        "icon": "fa-wand-magic-sparkles",
        "desc": "Autonomous 24/7 campaign tracking, dynamic ad creative reallocation, predictive lead scoring, and automated marketing health reports."
    },
    {
        "id": "ai-video",
        "title": "AI Video Creation",
        "category": "AI & Content",
        "icon": "fa-video",
        "desc": "Algorithmic storyboard generation, automated voiceovers, subtitle styling, and high-retention short-form video concepts built for viral engagement."
    },
    {
        "id": "performance-marketing",
        "title": "Performance Marketing",
        "category": "Paid Advertising",
        "icon": "fa-chart-line",
        "desc": "Laser-targeted Meta Ads, Google Search & Shopping campaigns, and LinkedIn B2B lead generation optimized for maximum ROAS and lowest CPA."
    },
    {
        "id": "seo",
        "title": "Search Engine Optimization (SEO)",
        "category": "Organic Growth",
        "icon": "fa-magnifying-glass-chart",
        "desc": "Comprehensive technical audits, high-intent keyword ranking strategies, speed optimization, and backlink authority building."
    },
    {
        "id": "website-marketing",
        "title": "Website Marketing & CRO",
        "category": "Digital",
        "icon": "fa-globe",
        "desc": "High-converting landing pages, interactive lead capture widgets, fast loading architectures, and conversion rate optimization (CRO)."
    },
    {
        "id": "tv-advertising",
        "title": "TV Advertising",
        "category": "Mass Media",
        "icon": "fa-tv",
        "desc": "Strategic media planning, primetime slot acquisitions, regional and national TV commercials engineered to build unmatched household credibility."
    },
    {
        "id": "radio-advertising",
        "title": "Radio Advertising & Jingles",
        "category": "Mass Media",
        "icon": "fa-radio",
        "desc": "Catchy sonic branding, memorable radio jingles, and RJ mentions broadcasted during peak morning and evening traffic drives."
    },
    {
        "id": "newspaper-advertising",
        "title": "Newspaper Advertising",
        "category": "Print & Media",
        "icon": "fa-newspaper",
        "desc": "Full-page jackets, ear panels, and classified inserts across leading national dailies and regional print editions."
    },
    {
        "id": "photography",
        "title": "Brand & Product Photography",
        "category": "Creative Production",
        "icon": "fa-camera",
        "desc": "High-resolution studio shoots, lifestyle action photography, and ecommerce catalog images designed to stop the scroll."
    },
    {
        "id": "videography",
        "title": "Commercial Videography",
        "category": "Creative Production",
        "icon": "fa-film",
        "desc": "Cinematic brand films, founder documentaries, TV commercial shoots, and on-location product demonstration videos."
    },
    {
        "id": "photo-editing",
        "title": "Photo Editing & Retouching",
        "category": "Creative Production",
        "icon": "fa-crop",
        "desc": "Pixel-perfect color grading, shadow creation, background removals, and high-end beauty retouching for print and digital assets."
    },
    {
        "id": "video-editing",
        "title": "Video Editing & Motion Graphics",
        "category": "Creative Production",
        "icon": "fa-sliders",
        "desc": "Fast-paced reel cuts, sound design, sound effects, motion graphics, and typography overlays optimized for mobile viewing."
    },
    {
        "id": "social-creatives",
        "title": "Social Media Creatives",
        "category": "Design & Content",
        "icon": "fa-image",
        "desc": "Cohesive Instagram carousels, bold infographic tiles, story templates, and thumb-stopping feed designs."
    },
    {
        "id": "banners-flyers",
        "title": "Banners & Flyers",
        "category": "Print Design",
        "icon": "fa-scroll",
        "desc": "Eye-catching exhibition pop-ups, retail point-of-sale displays, handouts, and promotional leaflets."
    },
    {
        "id": "print-design",
        "title": "Print & Packaging Design",
        "category": "Print Design",
        "icon": "fa-box-open",
        "desc": "Custom product packaging, unboxing experiences, luxury business cards, company brochures, and annual reports."
    },
    {
        "id": "branding-kits",
        "title": "Branding Kits & Identity",
        "category": "Brand Strategy",
        "icon": "fa-swatchbook",
        "desc": "Distinctive logos, signature color palettes, custom typography pairings, and full brand guideline manuals."
    },
    {
        "id": "market-research",
        "title": "Market & Industry Research",
        "category": "Intelligence",
        "icon": "fa-chart-pie",
        "desc": "Deep competitive intelligence, consumer sentiment analysis, market sizing, and whitespace discovery."
    },
    {
        "id": "consumer-research",
        "title": "Consumer Behavior Analysis",
        "category": "Intelligence",
        "icon": "fa-users-line",
        "desc": "Qualitative buyer personas, journey mapping, behavioral triggers, and focus group synthesis."
    },
    {
        "id": "content-creation",
        "title": "Content Creation & Copywriting",
        "category": "Design & Content",
        "icon": "fa-pen-fancy",
        "desc": "Persuasive sales copy, email nurture sequences, thought leadership articles, and viral campaign slogans."
    },
    {
        "id": "digital-marketing",
        "title": "Full-Funnel Digital Marketing",
        "category": "Digital",
        "icon": "fa-bullseye",
        "desc": "Integrated 360-degree digital roadmaps aligning paid search, social media, email marketing, and web analytics into a cohesive engine."
    }
]

PORTFOLIO_ITEMS = [
    {
        "client": "AeroFit Activewear",
        "service": "Social Media & Performance Ads",
        "metric": "4.2x ROAS",
        "image_color": "#1E293B",
        "summary": "Scaled direct-to-consumer athletic wear through high-retention workout Reels and hyper-targeted Meta ad campaigns, driving ₹3.8 Cr in sales."
    },
    {
        "client": "Delhi Pulse Metro Campaign",
        "service": "Metro Pillars & OOH Advertising",
        "metric": "1.2 Cr+ Monthly Commuter Reach",
        "image_color": "#0B0F19",
        "summary": "Dominated the Delhi Metro Blue Line with consecutive branded metro pillars and interactive QR code billboards for a premier fintech app."
    },
    {
        "client": "Zenith Cloud Solutions",
        "service": "B2B LinkedIn & SEO Overhaul",
        "metric": "+240% Inbound SQLs",
        "image_color": "#111827",
        "summary": "Engineered a targeted ABM campaign paired with technical SEO restructuring to rank for 80+ enterprise cloud keywords."
    },
    {
        "client": "Saffron Spice QSR Franchise",
        "service": "Viral Reels & Local Store Awareness",
        "metric": "8.5M+ Video Views",
        "image_color": "#1E1E24",
        "summary": "Hyper-local food influencer activations, mouthwatering macro food videography, and geo-fenced Instagram ads boosting footfall by 62%."
    }
]


@public_bp.route("/")
def home():
    return render_template(
        "public/home.html",
        services=SERVICES_LIST[:8],
        all_services_count=len(SERVICES_LIST),
        portfolio=PORTFOLIO_ITEMS
    )


@public_bp.route("/about")
def about():
    return render_template("public/about.html")


@public_bp.route("/services")
def services():
    category_filter = request.args.get("category", "All")
    if category_filter != "All":
        filtered_services = [s for s in SERVICES_LIST if s["category"] == category_filter]
    else:
        filtered_services = SERVICES_LIST

    categories = ["All"] + sorted(list(set(s["category"] for s in SERVICES_LIST)))
    return render_template(
        "public/services.html",
        services=filtered_services,
        categories=categories,
        current_category=category_filter
    )


@public_bp.route("/ai-studio")
def ai_studio():
    return render_template("public/ai_studio.html")


@public_bp.route("/portfolio")
def portfolio():
    return render_template("public/portfolio.html", portfolio=PORTFOLIO_ITEMS)


@public_bp.route("/case-studies")
def case_studies():
    return render_template("public/case_studies.html")


@public_bp.route("/pricing")
def pricing():
    return render_template("public/pricing.html")


@public_bp.route("/blog")
def blog():
    return render_template("public/blog.html")


@public_bp.route("/contact", methods=["GET", "POST"])
def contact():
    if request.method == "POST":
        full_name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        phone = request.form.get("phone", "").strip()
        company = request.form.get("company", "").strip()
        service_interest = request.form.get("service", "General Digital Marketing")
        message = request.form.get("message", "").strip()
        budget = request.form.get("budget", "Flexible")

        if not full_name or not email:
            flash("Please enter both your name and a valid email address.", "danger")
            return render_template("public/contact.html")

        # Split names
        name_parts = full_name.split(" ", 1)
        first_name = name_parts[0]
        last_name = name_parts[1] if len(name_parts) > 1 else ""

        # Find primary client to attach to (or default demo client)
        target_client = Client.query.first()
        target_client_id = target_client.id if target_client else 1

        # Heuristic AI Lead Scoring
        ai_score = LeadScore.WARM
        score_val = 70
        reason = f"Inquired for {service_interest}. Budget tier: {budget}."

        if budget in ["₹2 Lakh - ₹5 Lakh", "₹5 Lakh+"]:
            ai_score = LeadScore.HOT
            score_val = 90
            reason += " High budget tier qualifies lead as HOT."
        elif not company:
            ai_score = LeadScore.COLD
            score_val = 45
            reason += " Missing company name."

        # Save to database
        lead = Lead(
            client_id=target_client_id,
            first_name=first_name,
            last_name=last_name,
            email=email,
            phone=phone,
            company=company,
            source="Website Contact Form",
            status=LeadStatus.NEW,
            ai_score=ai_score,
            score_value=score_val,
            ai_score_reason=reason,
            notes=f"Service Requested: {service_interest}\nBudget: {budget}\n\nClient Note:\n{message}"
        )
        db.session.add(lead)

        # Create internal alert notification
        notif = Notification(
            user_id=1,  # Admin
            client_id=target_client_id,
            title=f"New Lead: {full_name}",
            message=f"New {ai_score} lead submitted from {company or 'Website'}. Inquired for {service_interest}.",
            type="success" if ai_score == LeadScore.HOT else "info",
            link="/dashboard/leads",
            is_read=False
        )
        db.session.add(notif)
        db.session.commit()

        flash("Thank you! Your inquiry has been submitted. An AI Marketing Strategist will contact you within 2 hours.", "success")
        return redirect(url_for("public.contact"))

    return render_template("public/contact.html")


@public_bp.route("/get-started")
def get_started():
    return render_template("public/get_started.html")

