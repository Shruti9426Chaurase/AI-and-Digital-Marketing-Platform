import io
from datetime import datetime, date, timedelta, timezone
from flask import (
    Blueprint, render_template, request, jsonify, flash,
    redirect, url_for, send_file, current_app
)
from flask_login import login_required, current_user

from app.extensions import db
from app.auth.security import role_required, get_current_client
from app.models.user import UserRole
from app.models.client import Client, BrandKit
from app.models.campaign import Campaign, CampaignMetric, CampaignObjective, CampaignStatus
from app.models.social import SocialAccount, SocialPost, SocialPlatform, PostStatus
from app.models.lead import Lead, Customer, LeadStatus, LeadScore
from app.models.seo import SEOProject, SEOKeyword
from app.models.ai import AIConversation, AIMessage, Recommendation, ActionStatus
from app.models.report import Report, ReportType, MarketResearch
from app.models.content import Content, Creative, ContentType, CreativeType
from app.models.system import AutomationRule

from app.services.ai_service import AIService
from app.services.analytics_service import AnalyticsService
from app.services.social_service import SocialService
from app.services.campaign_service import CampaignService
from app.services.seo_service import SEOService
from app.services.lead_service import LeadService
from app.services.report_service import ReportService
from app.services.automation_service import AutomationService

client_bp = Blueprint("client", __name__, url_prefix="/dashboard")


# =========================================================================
# 1. OVERVIEW DASHBOARD
# =========================================================================
@client_bp.route("/")
@login_required
@role_required(UserRole.CLIENT, UserRole.MARKETING_MANAGER, UserRole.ADMIN)
def dashboard():
    client = get_current_client()
    if not client:
        flash("No active client workspace found. Please seed demo data or register.", "warning")
        return redirect(url_for("public.home"))

    days = int(request.args.get("days", 30))
    overview = AnalyticsService.get_dashboard_overview(client.id, days=days)
    chart_data = AnalyticsService.get_trend_chart_data(client.id, days=days)
    recent_posts = SocialPost.query.filter_by(client_id=client.id).order_by(SocialPost.created_at.desc()).limit(4).all()
    recent_campaigns = Campaign.query.filter_by(client_id=client.id).order_by(Campaign.created_at.desc()).limit(3).all()

    return render_template(
        "client/dashboard.html",
        client=client,
        overview=overview,
        chart_data=chart_data,
        recent_posts=recent_posts,
        recent_campaigns=recent_campaigns,
        selected_days=days
    )


# =========================================================================
# 2. AI MARKETING AGENT
# =========================================================================
@client_bp.route("/ai-agent")
@login_required
@role_required(UserRole.CLIENT, UserRole.MARKETING_MANAGER, UserRole.ADMIN)
def ai_agent_view():
    client = get_current_client()
    conversations = AIConversation.query.filter_by(client_id=client.id).order_by(AIConversation.updated_at.desc()).all()
    active_conv_id = request.args.get("conv_id", type=int)

    active_conv = None
    if active_conv_id:
        active_conv = db.session.get(AIConversation, active_conv_id)
    if not active_conv and conversations:
        active_conv = conversations[0]

    messages = active_conv.messages.order_by(AIMessage.created_at.asc()).all() if active_conv else []

    return render_template(
        "client/ai_agent.html",
        client=client,
        conversations=conversations,
        active_conv=active_conv,
        messages=messages
    )


@client_bp.route("/ai-agent/chat", methods=["POST"])
@login_required
@role_required(UserRole.CLIENT, UserRole.MARKETING_MANAGER, UserRole.ADMIN)
def ai_agent_chat():
    client = get_current_client()
    user_msg = request.form.get("message", "").strip()
    conv_id = request.form.get("conversation_id", type=int)

    if not user_msg:
        flash("Message cannot be empty.", "warning")
        return redirect(url_for("client.ai_agent_view", conv_id=conv_id))

    result = AIService.chat_with_agent(client.id, current_user.id, user_msg, conversation_id=conv_id)
    return redirect(url_for("client.ai_agent_view", conv_id=result["conversation_id"]))


@client_bp.route("/ai-agent/action/confirm", methods=["POST"])
@login_required
@role_required(UserRole.CLIENT, UserRole.MARKETING_MANAGER, UserRole.ADMIN)
def confirm_ai_action():
    msg_id = request.form.get("message_id", type=int)
    result = AIService.execute_confirmed_action(msg_id, current_user.id)

    if result.get("success"):
        flash(result.get("message"), "success")
    else:
        flash(result.get("error", "Action failed to execute."), "danger")

    conv_id = request.form.get("conversation_id", type=int)
    return redirect(url_for("client.ai_agent_view", conv_id=conv_id))


# =========================================================================
# 3. CAMPAIGNS & 10-STEP WIZARD
# =========================================================================
@client_bp.route("/campaigns")
@login_required
@role_required(UserRole.CLIENT, UserRole.MARKETING_MANAGER, UserRole.ADMIN)
def campaigns_view():
    client = get_current_client()
    campaigns = CampaignService.list_campaigns(client.id)
    return render_template("client/campaigns.html", client=client, campaigns=campaigns)


@client_bp.route("/campaigns/create", methods=["GET", "POST"])
@login_required
@role_required(UserRole.CLIENT, UserRole.MARKETING_MANAGER, UserRole.ADMIN)
def create_campaign():
    client = get_current_client()
    if request.method == "POST":
        name = request.form.get("name")
        objective = request.form.get("objective")
        budget = float(request.form.get("budget", 0))
        target_audience = request.form.get("target_audience")
        platforms = request.form.getlist("platforms") or ["Instagram"]
        start_date_str = request.form.get("start_date")
        end_date_str = request.form.get("end_date")

        s_date = datetime.strptime(start_date_str, "%Y-%m-%d").date() if start_date_str else date.today()
        e_date = datetime.strptime(end_date_str, "%Y-%m-%d").date() if end_date_str else s_date + timedelta(days=30)

        CampaignService.create_campaign(
            client.id, name, objective, budget, target_audience, platforms, s_date, e_date
        )
        flash(f"Campaign '{name}' created and scheduled successfully!", "success")
        return redirect(url_for("client.campaigns_view"))

    return render_template("client/campaign_wizard.html", client=client)


@client_bp.route("/campaigns/<int:campaign_id>/status", methods=["POST"])
@login_required
@role_required(UserRole.CLIENT, UserRole.MARKETING_MANAGER, UserRole.ADMIN)
def update_campaign_status(campaign_id):
    new_status = request.form.get("status")
    CampaignService.update_status(campaign_id, new_status)
    flash(f"Campaign status updated to {new_status}.", "info")
    return redirect(url_for("client.campaigns_view"))


# =========================================================================
# 4. SOCIAL MEDIA MANAGEMENT & PUBLISHING
# =========================================================================
@client_bp.route("/social")
@login_required
@role_required(UserRole.CLIENT, UserRole.MARKETING_MANAGER, UserRole.ADMIN)
def social_view():
    client = get_current_client()
    accounts = SocialService.get_connected_accounts(client.id)
    posts = SocialPost.query.filter_by(client_id=client.id).order_by(SocialPost.created_at.desc()).all()
    return render_template("client/social.html", client=client, accounts=accounts, posts=posts)


@client_bp.route("/social/connect", methods=["POST"])
@login_required
@role_required(UserRole.CLIENT, UserRole.MARKETING_MANAGER, UserRole.ADMIN)
def connect_social_account():
    client = get_current_client()
    platform = request.form.get("platform")
    handle = request.form.get("handle")
    SocialService.connect_account(client.id, platform, handle)
    flash(f"Connected {platform} account {handle} successfully!", "success")
    return redirect(url_for("client.social_view"))


@client_bp.route("/social/post/schedule", methods=["POST"])
@login_required
@role_required(UserRole.CLIENT, UserRole.MARKETING_MANAGER, UserRole.ADMIN)
def schedule_social_post():
    client = get_current_client()
    platform = request.form.get("platform")
    content = request.form.get("content")
    hashtags = request.form.get("hashtags")
    time_str = request.form.get("scheduled_for")

    sched_dt = None
    if time_str:
        try:
            sched_dt = datetime.strptime(time_str, "%Y-%m-%dT%H:%M")
        except Exception:
            sched_dt = datetime.now(timezone.utc) + timedelta(days=1)

    SocialService.create_or_schedule_post(client.id, platform, content, hashtags, scheduled_for=sched_dt)
    flash("Post scheduled into Content Calendar!", "success")
    return redirect(url_for("client.calendar_view"))


@client_bp.route("/social/post/<int:post_id>/publish", methods=["POST"])
@login_required
@role_required(UserRole.CLIENT, UserRole.MARKETING_MANAGER, UserRole.ADMIN)
def publish_social_post(post_id):
    res = SocialService.publish_post_now(post_id)
    if res.get("status") == PostStatus.PUBLISHED:
        flash(res.get("message"), "success")
    else:
        flash(res.get("message"), "warning")
    return redirect(url_for("client.social_view"))


@client_bp.route("/social/post/<int:post_id>/delete", methods=["POST"])
@login_required
@role_required(UserRole.CLIENT, UserRole.MARKETING_MANAGER, UserRole.ADMIN)
def delete_social_post(post_id):
    SocialService.delete_post(post_id)
    flash("Post deleted successfully.", "info")
    return redirect(url_for("client.social_view"))


# =========================================================================
# 5. CONTENT CALENDAR
# =========================================================================
@client_bp.route("/calendar")
@login_required
@role_required(UserRole.CLIENT, UserRole.MARKETING_MANAGER, UserRole.ADMIN)
def calendar_view():
    client = get_current_client()
    posts = SocialPost.query.filter_by(client_id=client.id).order_by(SocialPost.scheduled_for.asc()).all()
    return render_template("client/calendar.html", client=client, posts=posts)


# =========================================================================
# 6. ANALYTICS & CHARTS
# =========================================================================
@client_bp.route("/analytics")
@login_required
@role_required(UserRole.CLIENT, UserRole.MARKETING_MANAGER, UserRole.ADMIN)
def analytics_view():
    client = get_current_client()
    days = int(request.args.get("days", 30))
    platform = request.args.get("platform", "All")

    overview = AnalyticsService.get_dashboard_overview(client.id, days=days)
    charts = AnalyticsService.get_trend_chart_data(client.id, days=days, platform=platform)
    metrics_table = CampaignMetric.query.filter_by(client_id=client.id).order_by(CampaignMetric.date.desc()).limit(30).all()

    return render_template(
        "client/analytics.html",
        client=client,
        overview=overview,
        charts=charts,
        metrics_table=metrics_table,
        selected_days=days,
        selected_platform=platform
    )


# =========================================================================
# 7. AI CONTENT TOOLS & GENERATORS
# =========================================================================
@client_bp.route("/content-studio", methods=["GET", "POST"])
@login_required
@role_required(UserRole.CLIENT, UserRole.MARKETING_MANAGER, UserRole.ADMIN)
def content_studio_view():
    client = get_current_client()
    generated_result = None

    if request.method == "POST":
        prompt = request.form.get("prompt")
        content_type = request.form.get("content_type", "Caption")
        platform = request.form.get("platform", "Instagram")
        tone = request.form.get("tone", "High Energy & Bold")
        audience = request.form.get("audience", "Urban Youth")

        generated_result = AIService.generate_content(
            client.id, prompt, content_type, platform, tone, audience
        )

        # Save to database
        item = Content(
            client_id=client.id,
            title=f"{content_type} — {prompt[:30]}",
            content_type=content_type,
            prompt=prompt,
            generated_text=generated_result,
            platform=platform,
            tone=tone,
            target_audience=audience
        )
        db.session.add(item)
        db.session.commit()
        flash("New marketing copy generated and saved to library!", "success")

    saved_contents = Content.query.filter_by(client_id=client.id).order_by(Content.created_at.desc()).limit(10).all()
    return render_template(
        "client/content_studio.html",
        client=client,
        generated_result=generated_result,
        saved_contents=saved_contents
    )


# =========================================================================
# 8. CREATIVE STUDIO & MEDIA TOOLS
# =========================================================================
@client_bp.route("/creatives")
@login_required
@role_required(UserRole.CLIENT, UserRole.MARKETING_MANAGER, UserRole.ADMIN)
def creatives_view():
    client = get_current_client()
    creatives = Creative.query.filter_by(client_id=client.id).order_by(Creative.created_at.desc()).all()
    return render_template("client/creatives.html", client=client, creatives=creatives)


# =========================================================================
# 9. PERFORMANCE ADS MANAGEMENT
# =========================================================================
@client_bp.route("/ads")
@login_required
@role_required(UserRole.CLIENT, UserRole.MARKETING_MANAGER, UserRole.ADMIN)
def ads_view():
    client = get_current_client()
    overview = AnalyticsService.get_dashboard_overview(client.id, days=30)
    ad_campaigns = Campaign.query.filter_by(client_id=client.id).all()
    return render_template("client/ads.html", client=client, overview=overview, campaigns=ad_campaigns)


# =========================================================================
# 10. LEADS & CRM
# =========================================================================
@client_bp.route("/leads")
@login_required
@role_required(UserRole.CLIENT, UserRole.MARKETING_MANAGER, UserRole.ADMIN)
def leads_view():
    client = get_current_client()
    leads = LeadService.list_leads(client.id)
    customers = Customer.query.filter_by(client_id=client.id).all()
    return render_template("client/leads.html", client=client, leads=leads, customers=customers)


@client_bp.route("/leads/add", methods=["POST"])
@login_required
@role_required(UserRole.CLIENT, UserRole.MARKETING_MANAGER, UserRole.ADMIN)
def add_lead():
    client = get_current_client()
    fn = request.form.get("first_name")
    ln = request.form.get("last_name")
    email = request.form.get("email")
    phone = request.form.get("phone")
    company = request.form.get("company")
    source = request.form.get("source", "Manual CRM Entry")
    notes = request.form.get("notes")

    LeadService.create_lead(client.id, fn, ln, email, phone, company, source, notes)
    flash(f"Lead '{fn} {ln}' added and automatically scored by AI!", "success")
    return redirect(url_for("client.leads_view"))


@client_bp.route("/leads/<int:lead_id>/status", methods=["POST"])
@login_required
@role_required(UserRole.CLIENT, UserRole.MARKETING_MANAGER, UserRole.ADMIN)
def update_lead_status(lead_id):
    new_status = request.form.get("status")
    LeadService.update_lead_status(lead_id, new_status)
    flash(f"Lead status updated to {new_status}.", "info")
    return redirect(url_for("client.leads_view"))


# =========================================================================
# 11. AUDIENCE
# =========================================================================
@client_bp.route("/audience")
@login_required
@role_required(UserRole.CLIENT, UserRole.MARKETING_MANAGER, UserRole.ADMIN)
def audience_view():
    client = get_current_client()
    return render_template("client/audience.html", client=client)


# =========================================================================
# 12. SEO MANAGEMENT SUITE
# =========================================================================
@client_bp.route("/seo")
@login_required
@role_required(UserRole.CLIENT, UserRole.MARKETING_MANAGER, UserRole.ADMIN)
def seo_view():
    client = get_current_client()
    proj = SEOService.get_or_create_project(client.id, client.website or "https://aerofitwear.com")
    keywords = proj.keywords.all()
    return render_template("client/seo.html", client=client, project=proj, keywords=keywords)


@client_bp.route("/seo/audit", methods=["POST"])
@login_required
@role_required(UserRole.CLIENT, UserRole.MARKETING_MANAGER, UserRole.ADMIN)
def run_seo_audit():
    proj_id = request.form.get("project_id", type=int)
    SEOService.run_audit(proj_id)
    flash("SEO technical crawl completed! Scores and recommendations updated.", "success")
    return redirect(url_for("client.seo_view"))


@client_bp.route("/seo/keyword/add", methods=["POST"])
@login_required
@role_required(UserRole.CLIENT, UserRole.MARKETING_MANAGER, UserRole.ADMIN)
def add_seo_keyword():
    proj_id = request.form.get("project_id", type=int)
    kw = request.form.get("keyword")
    rank = int(request.form.get("current_rank", 10))
    vol = int(request.form.get("search_volume", 1500))

    SEOService.add_keyword(proj_id, kw, rank, vol)
    flash(f"Keyword '{kw}' added to tracking.", "success")
    return redirect(url_for("client.seo_view"))


# =========================================================================
# 13. MARKET & CONSUMER RESEARCH
# =========================================================================
@client_bp.route("/research")
@login_required
@role_required(UserRole.CLIENT, UserRole.MARKETING_MANAGER, UserRole.ADMIN)
def research_view():
    client = get_current_client()
    researches = MarketResearch.query.filter_by(client_id=client.id).order_by(MarketResearch.created_at.desc()).all()
    return render_template("client/research.html", client=client, researches=researches)


@client_bp.route("/research/generate", methods=["POST"])
@login_required
@role_required(UserRole.CLIENT, UserRole.MARKETING_MANAGER, UserRole.ADMIN)
def generate_research():
    client = get_current_client()
    industry = request.form.get("industry")
    product = request.form.get("product")
    location = request.form.get("location", "India / Global")
    competitors = request.form.get("competitors", "Market leaders")

    res = MarketResearch(
        client_id=client.id,
        industry=industry,
        product=product,
        location=location,
        competitors=competitors,
        market_overview=f"The {industry} sector in {location} is experiencing 24% CAGR driven by D2C adoption and social commerce.",
        customer_personas_json=[
            {"name": "Urban Fitness Enthusiast", "age": "22-34", "pain_point": "Poor fabric durability and chafing", "trigger": "Short-form video workout transformations"},
            {"name": "College Athlete", "age": "18-24", "pain_point": "High price tags of international legacy brands", "trigger": "Meme marketing and community ambassador programs"}
        ],
        trends_json=["Shift from static imagery to raw gym videography", "Higher consumer willingness to buy via Instagram Shop"],
        opportunities_json=["Dominate Metro pillar media for high commuter frequency", "Launch WhatsApp VIP early-access drops"],
        risks_json=["Rising Meta CPMs during peak festival quarter"]
    )
    db.session.add(res)
    db.session.commit()
    flash("Comprehensive Market & Consumer Research Dossier generated!", "success")
    return redirect(url_for("client.research_view"))


# =========================================================================
# 14. AUTOMATED REPORTS
# =========================================================================
@client_bp.route("/reports")
@login_required
@role_required(UserRole.CLIENT, UserRole.MARKETING_MANAGER, UserRole.ADMIN)
def reports_view():
    client = get_current_client()
    reports = ReportService.list_reports(client.id)
    return render_template("client/reports.html", client=client, reports=reports)


@client_bp.route("/reports/generate", methods=["POST"])
@login_required
@role_required(UserRole.CLIENT, UserRole.MARKETING_MANAGER, UserRole.ADMIN)
def generate_new_report():
    client = get_current_client()
    rep_type = request.form.get("report_type", ReportType.WEEKLY)
    days = 7 if rep_type == ReportType.WEEKLY else 30
    ReportService.generate_report(client.id, report_type=rep_type, period_days=days)
    flash(f"New {rep_type} generated successfully!", "success")
    return redirect(url_for("client.reports_view"))


@client_bp.route("/reports/<int:report_id>/download-csv")
@login_required
@role_required(UserRole.CLIENT, UserRole.MARKETING_MANAGER, UserRole.ADMIN)
def download_report_csv(report_id):
    csv_stream = ReportService.export_report_to_csv(report_id)
    mem_file = io.BytesIO()
    mem_file.write(csv_stream.getvalue().encode("utf-8"))
    mem_file.seek(0)
    return send_file(
        mem_file,
        mimetype="text/csv",
        as_attachment=True,
        download_name=f"BackkBenchers_Report_{report_id}.csv"
    )


# =========================================================================
# 15. AI RECOMMENDATIONS
# =========================================================================
@client_bp.route("/recommendations")
@login_required
@role_required(UserRole.CLIENT, UserRole.MARKETING_MANAGER, UserRole.ADMIN)
def recommendations_view():
    client = get_current_client()
    recs = Recommendation.query.filter_by(client_id=client.id).order_by(Recommendation.created_at.desc()).all()
    return render_template("client/recommendations.html", client=client, recommendations=recs)


# =========================================================================
# 16. MANUAL DATA & CSV IMPORT (HYBRID MODE)
# =========================================================================
@client_bp.route("/manual-data", methods=["GET", "POST"])
@login_required
@role_required(UserRole.CLIENT, UserRole.MARKETING_MANAGER, UserRole.ADMIN)
def manual_data_view():
    client = get_current_client()

    if request.method == "POST":
        if "csv_file" in request.files:
            file = request.files["csv_file"]
            if file and file.filename.endswith(".csv"):
                res = AnalyticsService.import_csv_metrics(client.id, file)
                if res.get("success"):
                    flash(f"Successfully imported {res.get('count')} metric records from CSV!", "success")
                else:
                    flash(f"CSV import error: {res.get('error')}", "danger")
            else:
                flash("Please upload a valid .csv file.", "warning")
            return redirect(url_for("client.manual_data_view"))

        # Single Manual Metric Form
        date_str = request.form.get("date")
        platform = request.form.get("platform", "Manual")
        reach = int(request.form.get("reach", 0))
        impressions = int(request.form.get("impressions", reach))
        clicks = int(request.form.get("clicks", 0))
        conversions = int(request.form.get("conversions", 0))
        spend = float(request.form.get("spend", 0.0))
        revenue = float(request.form.get("revenue", 0.0))

        m_date = datetime.strptime(date_str, "%Y-%m-%d").date() if date_str else date.today()
        metric = CampaignMetric(
            client_id=client.id,
            date=m_date,
            platform=platform,
            data_source="MANUAL",
            impressions=impressions,
            reach=reach,
            clicks=clicks,
            conversions=conversions,
            spend=spend,
            revenue=revenue
        )
        db.session.add(metric)
        db.session.commit()
        flash("Manual performance entry saved! Dashboard charts updated.", "success")
        return redirect(url_for("client.manual_data_view"))

    recent_manual = CampaignMetric.query.filter_by(
        client_id=client.id, data_source="MANUAL"
    ).order_by(CampaignMetric.date.desc()).limit(20).all()

    return render_template("client/manual_data.html", client=client, manual_metrics=recent_manual)


# =========================================================================
# 17. BRAND KIT MANAGEMENT
# =========================================================================
@client_bp.route("/brand-kit", methods=["GET", "POST"])
@login_required
@role_required(UserRole.CLIENT, UserRole.MARKETING_MANAGER, UserRole.ADMIN)
def brand_kit_view():
    client = get_current_client()
    kit = client.brand_kit
    if not kit:
        kit = BrandKit(client_id=client.id, brand_name=client.company_name)
        db.session.add(kit)
        db.session.commit()

    if request.method == "POST":
        kit.brand_name = request.form.get("brand_name")
        kit.tagline = request.form.get("tagline")
        kit.mission = request.form.get("mission")
        kit.target_audience = request.form.get("target_audience")
        kit.primary_color = request.form.get("primary_color", "#FFC72C")
        kit.secondary_color = request.form.get("secondary_color", "#EF4444")
        kit.accent_color = request.form.get("accent_color", "#0B0F19")
        kit.font_family = request.form.get("font_family", "Inter, sans-serif")
        kit.brand_guidelines = request.form.get("brand_guidelines")

        db.session.commit()
        flash("Brand Kit updated successfully! AI Agent will now use these guidelines.", "success")
        return redirect(url_for("client.brand_kit_view"))

    return render_template("client/brand_kit.html", client=client, kit=kit)


# =========================================================================
# 18. AUTOMATION RULES
# =========================================================================
@client_bp.route("/automation")
@login_required
@role_required(UserRole.CLIENT, UserRole.MARKETING_MANAGER, UserRole.ADMIN)
def automation_view():
    client = get_current_client()
    rules = AutomationService.list_rules(client.id)
    return render_template("client/automation.html", client=client, rules=rules)


@client_bp.route("/automation/<int:rule_id>/toggle", methods=["POST"])
@login_required
@role_required(UserRole.CLIENT, UserRole.MARKETING_MANAGER, UserRole.ADMIN)
def toggle_automation(rule_id):
    is_active = AutomationService.toggle_rule(rule_id)
    state_str = "Enabled" if is_active else "Paused"
    flash(f"Automation Rule {state_str}!", "info")
    return redirect(url_for("client.automation_view"))

