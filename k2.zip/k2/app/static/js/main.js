/**
 * BACKKBENCHERS AI Marketing SaaS Platform - Core Client Utilities
 */

document.addEventListener("DOMContentLoaded", function () {
  // Initialize Bootstrap Tooltips
  const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
  tooltipTriggerList.map(function (tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl);
  });

  // Auto-dismiss Flash Alerts after 5 seconds
  const autoAlerts = document.querySelectorAll(".alert-dismissible");
  autoAlerts.forEach(function (alert) {
    setTimeout(function () {
      const bsAlert = new bootstrap.Alert(alert);
      bsAlert.close();
    }, 6000);
  });

  // Global CSRF Token Fetch Setup
  window.getCsrfToken = function () {
    const meta = document.querySelector('meta[name="csrf-token"]');
    return meta ? meta.getAttribute("content") : "";
  };

  // Secure AJAX Helper
  window.secureFetch = async function (url, options = {}) {
    const headers = options.headers || {};
    if (!headers["X-CSRFToken"] && !headers["x-csrf-token"]) {
      headers["X-CSRFToken"] = window.getCsrfToken();
    }
    if (!headers["Content-Type"] && !(options.body instanceof FormData)) {
      headers["Content-Type"] = "application/json";
    }
    options.headers = headers;
    return fetch(url, options);
  };

  // Copy to Clipboard Utility
  window.copyToClipboard = function (text, btnElement) {
    navigator.clipboard.writeText(text).then(() => {
      if (btnElement) {
        const originalHtml = btnElement.innerHTML;
        btnElement.innerHTML = '<i class="fas fa-check"></i> Copied!';
        btnElement.classList.add("btn-success");
        setTimeout(() => {
          btnElement.innerHTML = originalHtml;
          btnElement.classList.remove("btn-success");
        }, 2000);
      }
    }).catch(err => {
      console.error("Could not copy text: ", err);
    });
  };

  // One-Click Demo Login Fill Helper
  window.fillDemoLogin = function (role) {
    const emailField = document.getElementById("email");
    const passField = document.getElementById("password");
    if (!emailField || !passField) return;

    if (role === "admin") {
      emailField.value = "admin@backkbenchers.com";
      passField.value = "Admin@1234";
    } else if (role === "manager") {
      emailField.value = "manager@backkbenchers.com";
      passField.value = "Manager@1234";
    } else if (role === "client") {
      emailField.value = "client@backkbenchers.com";
      passField.value = "Client@1234";
    }
  };
});

