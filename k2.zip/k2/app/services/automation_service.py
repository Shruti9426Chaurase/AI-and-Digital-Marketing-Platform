from datetime import datetime, timezone
from typing import Dict, Any, List
from app.extensions import db
from app.models.system import AutomationRule, Notification
from app.models.ai import Recommendation, RecommendationPriority
from app.models.campaign import Campaign
from app.models.social import SocialPost, PostStatus

class AutomationService:
    """Event-Driven Marketing Automation Engine."""

    @classmethod
    def list_rules(cls, client_id: int) -> List[AutomationRule]:
        rules = AutomationRule.query.filter_by(client_id=client_id).all()
        if not rules:
            # Seed default production automation rules
            default_rules = [
                AutomationRule(
                    client_id=client_id,
                    name="Auto-Diagnose Engagement Drops > 15%",
                    event_trigger="ENGAGEMENT_DROP",
                    condition_json={"threshold_percent": 15, "channel": "Instagram"},
                    action_type="GENERATE_RECOMMENDATION",
                    action_payload_json={"priority": "HIGH", "category": "Social Media"},
                    is_active=True
                ),
                AutomationRule(
                    client_id=client_id,
                    name="Pause Campaign at 98% Budget Limit",
                    event_trigger="BUDGET_LIMIT",
                    condition_json={"threshold_percent": 98},
                    action_type="PAUSE_CAMPAIGN",
                    action_payload_json={"alert": True},
                    is_active=True
                ),
                AutomationRule(
                    client_id=client_id,
                    name="Instant AI Lead Scoring & Team Alert",
                    event_trigger="NEW_LEAD",
                    condition_json={"auto_score": True},
                    action_type="SCORE_LEAD",
                    action_payload_json={"notify_hot_leads": True},
                    is_active=True
                ),
                AutomationRule(
                    client_id=client_id,
                    name="Weekly Monday Executive Review Generation",
                    event_trigger="WEEKLY_DIGEST",
                    condition_json={"day": "Monday", "time": "09:00"},
                    action_type="GENERATE_REPORT",
                    action_payload_json={"report_type": "Weekly Marketing Performance"},
                    is_active=True
                )
            ]
            db.session.add_all(default_rules)
            db.session.commit()
            return default_rules
        return rules

    @classmethod
    def toggle_rule(cls, rule_id: int) -> bool:
        rule = db.session.get(AutomationRule, rule_id)
        if rule:
            rule.is_active = not rule.is_active
            db.session.commit()
            return rule.is_active
        return False

    @classmethod
    def execute_rule_trigger(cls, client_id: int, trigger_type: str, context_data: Dict[str, Any] = None) -> Dict[str, Any]:
        """Evaluates active automation rules and executes corresponding actions."""
        active_rules = AutomationRule.query.filter_by(
            client_id=client_id, event_trigger=trigger_type, is_active=True
        ).all()

        executed_actions = []
        for rule in active_rules:
            rule.last_triggered_at = datetime.now(timezone.utc)
            
            if rule.action_type == "GENERATE_RECOMMENDATION":
                rec = Recommendation(
                    client_id=client_id,
                    title="Engagement Drop Mitigation Triggered",
                    problem="Instagram engagement rate dropped by 18% over the past 14 days.",
                    insight="Short-form video volume decreased by 50% while audience peak activity shifted to evenings.",
                    recommended_action="Publish 3 Reels this week between 7:30 PM and 9:30 PM with pinned engagement questions.",
                    expected_impact="+25% engagement recovery",
                    priority=RecommendationPriority.HIGH,
                    confidence=92,
                    category="Social Media",
                    status="PENDING"
                )
                db.session.add(rec)
                executed_actions.append(f"Created High-Priority AI Recommendation for Rule: {rule.name}")

            elif rule.action_type == "PAUSE_CAMPAIGN":
                # Check campaigns near budget
                campaigns = Campaign.query.filter_by(client_id=client_id, status="ACTIVE").all()
                for c in campaigns:
                    if c.budget > 0 and (c.spend / c.budget) >= 0.95:
                        c.status = "PAUSED"
                        notif = Notification(
                            user_id=1,
                            client_id=client_id,
                            title=f"Campaign Paused: {c.name}",
                            message="Campaign reached 95%+ of budget limit. Automatically paused to prevent overspend.",
                            type="warning",
                            link="/dashboard/campaigns",
                            is_read=False
                        )
                        db.session.add(notif)
                        executed_actions.append(f"Paused campaign '{c.name}' to prevent budget overrun.")

        db.session.commit()
        return {"success": True, "executed": executed_actions}

