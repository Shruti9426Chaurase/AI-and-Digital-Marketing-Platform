from datetime import datetime, timezone
from typing import Dict, Any, List, Optional
from app.extensions import db
from app.models.lead import Lead, Customer, LeadStatus, LeadScore

class LeadService:
    """Customer Engagement & AI Lead Scoring CRM Service."""

    @classmethod
    def list_leads(cls, client_id: int) -> List[Lead]:
        return Lead.query.filter_by(client_id=client_id).order_by(Lead.created_at.desc()).all()

    @classmethod
    def create_lead(
        cls, client_id: int, first_name: str, last_name: str, email: str,
        phone: Optional[str] = None, company: Optional[str] = None,
        source: str = "Website", notes: Optional[str] = None
    ) -> Lead:
        """Creates and automatically scores a new prospective lead."""
        # AI Heuristic Lead Scoring
        score_val = 65
        score_badge = LeadScore.WARM
        reason = f"Source: {source}."

        if company and len(company) > 3:
            score_val += 15
            reason += " Verified company profile."

        if phone and len(phone) >= 10:
            score_val += 10
            reason += " Direct phone contact provided."

        if score_val >= 85:
            score_badge = LeadScore.HOT
        elif score_val < 55:
            score_badge = LeadScore.COLD

        lead = Lead(
            client_id=client_id,
            first_name=first_name,
            last_name=last_name,
            email=email,
            phone=phone,
            company=company,
            source=source,
            status=LeadStatus.NEW,
            ai_score=score_badge,
            score_value=score_val,
            ai_score_reason=reason,
            notes=notes
        )
        db.session.add(lead)
        db.session.commit()
        return lead

    @classmethod
    def update_lead_status(cls, lead_id: int, new_status: str) -> bool:
        lead = db.session.get(Lead, lead_id)
        if not lead:
            return False

        lead.status = new_status
        # If converted, create Customer record
        if new_status == LeadStatus.CONVERTED:
            customer = Customer.query.filter_by(lead_id=lead.id).first()
            if not customer:
                customer = Customer(
                    client_id=lead.client_id,
                    lead_id=lead.id,
                    name=lead.full_name,
                    email=lead.email,
                    phone=lead.phone,
                    company=lead.company,
                    lifetime_value=75000.0,
                    status="Active"
                )
                db.session.add(customer)

        db.session.commit()
        return True

