from datetime import date, datetime, timezone
from typing import Dict, Any, List, Optional
from app.extensions import db
from app.models.campaign import Campaign, CampaignMetric, CampaignStatus, CampaignObjective
from app.models.system import Notification

class CampaignService:
    """10-Step Campaign Management & Optimization Service."""

    @classmethod
    def list_campaigns(cls, client_id: int) -> List[Campaign]:
        return Campaign.query.filter_by(client_id=client_id).order_by(Campaign.created_at.desc()).all()

    @classmethod
    def create_campaign(
        cls, client_id: int, name: str, objective: str, budget: float,
        target_audience: str, platforms: List[str], start_date: Optional[date] = None,
        end_date: Optional[date] = None, content_strategy: Optional[str] = None
    ) -> Campaign:
        """Creates a campaign from the wizard."""
        ai_summary = f"Allocated ₹{budget:,.0f} across {', '.join(platforms)}. Objective: {objective}."

        campaign = Campaign(
            client_id=client_id,
            name=name,
            objective=objective,
            status=CampaignStatus.ACTIVE if start_date and start_date <= date.today() else CampaignStatus.SCHEDULED,
            budget=budget,
            spend=0.0,
            start_date=start_date or date.today(),
            end_date=end_date,
            target_audience_desc=target_audience,
            platforms_json=platforms,
            ai_recommendations_summary=ai_summary
        )
        db.session.add(campaign)
        db.session.commit()
        return campaign

    @classmethod
    def update_status(cls, campaign_id: int, status: str) -> bool:
        camp = db.session.get(Campaign, campaign_id)
        if camp:
            camp.status = status
            db.session.commit()
            return True
        return False

