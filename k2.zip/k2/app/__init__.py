import os
from datetime import datetime, date, timezone
from flask import Flask, render_template, request
from app.config import config_by_name
from app.extensions import db, migrate, login_manager, csrf


def create_app(config_name=None):
    """Application factory for the BACKKBENCHERS AI Marketing Platform."""
    if not config_name:
        config_name = os.environ.get("FLASK_ENV", "development")

    app = Flask(__name__, template_folder="templates", static_folder="static")

    # Load configuration
    cfg = config_by_name.get(config_name, config_by_name["default"])
    app.config.from_object(cfg)

    # Initialize extensions
    db.init_app(app)
    migrate.init_app(app, db)
    login_manager.init_app(app)
    csrf.init_app(app)

    # Ensure upload directories exist
    os.makedirs(app.config.get("UPLOAD_FOLDER", os.path.join(app.root_path, "static", "uploads")), exist_ok=True)

    # User loader for Flask-Login
    from app.models.user import User

    @login_manager.user_loader
    def load_user(user_id):
        try:
            return db.session.get(User, int(user_id))
        except (ValueError, TypeError):
            return None

    # Global Context Processor
    @app.context_processor
    def inject_globals():
        unread = 0
        from flask_login import current_user
        if current_user and current_user.is_authenticated:
            try:
                from app.models.system import Notification
                unread = Notification.query.filter_by(user_id=current_user.id, is_read=False).count()
            except Exception:
                unread = 0

        return {
            "brand_name": app.config.get("BRAND_NAME", "BACKKBENCHERS"),
            "brand_tagline": app.config.get("BRAND_TAGLINE", "AI-powered marketing that turns brands into marketing machines"),
            "demo_mode": app.config.get("DEMO_MODE", True),
            "unread_notifications": unread,
            "current_year": datetime.now(timezone.utc).year,
            "current_date": date.today()
        }

    # Custom Jinja Template Filters
    @app.template_filter("currency")
    def format_currency(value):
        try:
            val = float(value or 0)
            return f"₹{val:,.2f}"
        except (ValueError, TypeError):
            return f"₹{value}"

    @app.template_filter("number_compact")
    def format_number_compact(value):
        try:
            val = float(value or 0)
            if val >= 1_000_000:
                return f"{val / 1_000_000:.1f}M"
            elif val >= 1_000:
                return f"{val / 1_000:.1f}K"
            return f"{int(val)}"
        except (ValueError, TypeError):
            return str(value)

    # Register Error Handlers
    @app.errorhandler(400)
    def bad_request(error):
        return render_template("errors/400.html"), 400

    @app.errorhandler(403)
    def forbidden(error):
        return render_template("errors/403.html"), 403

    @app.errorhandler(404)
    def not_found(error):
        return render_template("errors/404.html"), 404

    @app.errorhandler(429)
    def ratelimit_exceeded(error):
        return render_template("errors/429.html"), 429

    @app.errorhandler(500)
    def internal_error(error):
        db.session.rollback()
        return render_template("errors/500.html"), 500

    # Register Blueprints
    from app.routes.public_routes import public_bp
    from app.routes.auth_routes import auth_bp
    from app.routes.client_routes import client_bp
    from app.routes.admin_routes import admin_bp
    from app.routes.api_routes import api_bp

    app.register_blueprint(public_bp)
    app.register_blueprint(auth_bp)
    app.register_blueprint(client_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(api_bp)

    return app


def auto_initialize_and_seed():
    """
    Idempotent database initialization and seeding.
    Safe to execute multiple times without overwriting or duplicating data.
    """
    app = create_app(os.environ.get("FLASK_ENV", "development"))
    with app.app_context():
        db.create_all()
        from scripts.seed_demo_data import run_seed
        run_seed()
    return app
