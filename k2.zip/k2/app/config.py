import os
from pathlib import Path
from dotenv import load_dotenv

# Load .env file from project root
BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")


class BaseConfig:
    SECRET_KEY = os.environ.get("SECRET_KEY", "backkbenchers-default-secret-key-32ch-min")
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # Database URL handling (auto-fix postgres:// -> postgresql:// for SQLAlchemy 1.4+)
    db_url = os.environ.get("DATABASE_URL", f"sqlite:///{BASE_DIR / 'backkbenchers.db'}")
    if db_url.startswith("postgres://"):
        db_url = db_url.replace("postgres://", "postgresql://", 1)
    SQLALCHEMY_DATABASE_URI = db_url

    # CSRF Protection
    WTF_CSRF_ENABLED = True
    WTF_CSRF_TIME_LIMIT = 3600

    # AI Integration Settings
    AI_PROVIDER = os.environ.get("AI_PROVIDER", "mock").lower()
    OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "")
    GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "")

    # Application Branding
    BRAND_NAME = "BACKKBENCHERS"
    BRAND_TAGLINE = "AI-powered marketing that turns brands into marketing machines"
    DEMO_MODE = os.environ.get("DEMO_MODE", "True").lower() in ("true", "1", "yes")

    # Static & Upload Folders
    UPLOAD_FOLDER = BASE_DIR / "app" / "static" / "uploads"
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16 MB max


class DevelopmentConfig(BaseConfig):
    DEBUG = True
    TESTING = False


class ProductionConfig(BaseConfig):
    DEBUG = False
    TESTING = False
    SESSION_COOKIE_SECURE = True
    REMEMBER_COOKIE_SECURE = True
    SESSION_COOKIE_HTTPONLY = True


class TestingConfig(BaseConfig):
    TESTING = True
    DEBUG = True
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
    WTF_CSRF_ENABLED = False


config_by_name = {
    "development": DevelopmentConfig,
    "production": ProductionConfig,
    "testing": TestingConfig,
    "default": DevelopmentConfig
}

