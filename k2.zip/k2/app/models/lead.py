from datetime import datetime, timezone
from app.extensions import db


class LeadStatus:
    NEW = "NEW"
    CONTACTED = "CONTACTED"
    QUALIFIED = "QUALIFIED"
    CONVERTED = "CONVERTED"
    LOST = "LOST"


class LeadScore:
    HOT = "HOT"
    WARM = "WARM"
    COLD = "COLD"


class Lead(db.Model):
    __tablename__ = "leads"

    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey("clients.id"), nullable=False)
    first_name = db.Column(db.String(64), nullable=False)
    last_name = db.Column(db.String(64), nullable=True)
    email = db.Column(db.String(120), nullable=False)
    phone = db.Column(db.String(32), nullable=True)
    company = db.Column(db.String(128), nullable=True)
    source = db.Column(db.String(64), default="Website")
    status = db.Column(db.String(32), default=LeadStatus.NEW, nullable=False)
    ai_score = db.Column(db.String(16), default=LeadScore.WARM, nullable=False)
    score_value = db.Column(db.Integer, default=60, nullable=False)
    ai_score_reason = db.Column(db.Text, nullable=True)
    notes = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = db.Column(
        db.DateTime,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False
    )

    client = db.relationship("Client", back_populates="leads")
    customer = db.relationship("Customer", uselist=False, back_populates="lead")

    @property
    def full_name(self) -> str:
        return f"{self.first_name} {self.last_name or ''}".strip()

    def __repr__(self):
        return f"<Lead {self.full_name} ({self.ai_score})>"


class Customer(db.Model):
    __tablename__ = "customers"

    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey("clients.id"), nullable=False)
    lead_id = db.Column(db.Integer, db.ForeignKey("leads.id"), nullable=True)
    name = db.Column(db.String(128), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    phone = db.Column(db.String(32), nullable=True)
    company = db.Column(db.String(128), nullable=True)
    lifetime_value = db.Column(db.Float, default=0.0, nullable=False)
    orders_count = db.Column(db.Integer, default=1, nullable=False)
    status = db.Column(db.String(32), default="Active", nullable=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)

    client = db.relationship("Client", back_populates="customers")
    lead = db.relationship("Lead", back_populates="customer")

    def __repr__(self):
        return f"<Customer {self.name} (LTV: ₹{self.lifetime_value:,.2f})>"

