from datetime import datetime, timezone
from app.extensions import db


class SEOProject(db.Model):
    __tablename__ = "seo_projects"

    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey("clients.id"), nullable=False)
    website_url = db.Column(db.String(256), nullable=False)
    health_score = db.Column(db.Integer, default=80, nullable=False)
    technical_score = db.Column(db.Integer, default=85, nullable=False)
    content_score = db.Column(db.Integer, default=80, nullable=False)
    backlink_score = db.Column(db.Integer, default=75, nullable=False)
    organic_traffic_estimate = db.Column(db.Integer, default=10000, nullable=False)
    total_keywords = db.Column(db.Integer, default=10, nullable=False)
    meta_title = db.Column(db.String(256), nullable=True)
    meta_description = db.Column(db.Text, nullable=True)
    audit_data_json = db.Column(db.JSON, default=dict)
    last_audited_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = db.Column(
        db.DateTime,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False
    )

    client = db.relationship("Client", back_populates="seo_projects")
    keywords = db.relationship("SEOKeyword", back_populates="project", cascade="all, delete-orphan")

    def __repr__(self):
        return f"<SEOProject {self.website_url} (Health: {self.health_score}%)>"


class SEOKeyword(db.Model):
    __tablename__ = "seo_keywords"

    id = db.Column(db.Integer, primary_key=True)
    project_id = db.Column(db.Integer, db.ForeignKey("seo_projects.id"), nullable=False)
    keyword = db.Column(db.String(128), nullable=False)
    current_rank = db.Column(db.Integer, default=50, nullable=False)
    previous_rank = db.Column(db.Integer, default=55, nullable=False)
    search_volume = db.Column(db.Integer, default=1000, nullable=False)
    difficulty = db.Column(db.Integer, default=45, nullable=False)
    url_target = db.Column(db.String(256), nullable=True)
    updated_at = db.Column(
        db.DateTime,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False
    )

    project = db.relationship("SEOProject", back_populates="keywords")

    @property
    def rank_change(self) -> int:
        return self.previous_rank - self.current_rank

    def __repr__(self):
        return f"<SEOKeyword '{self.keyword}' (Rank: #{self.current_rank})>"

