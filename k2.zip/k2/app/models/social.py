from datetime import datetime, timezone
from sqlalchemy.ext.hybrid import hybrid_property
from app.extensions import db


class SocialPlatform:
    INSTAGRAM = "Instagram"
    FACEBOOK = "Facebook"
    LINKEDIN = "LinkedIn"
    TWITTER = "X (Twitter)"
    YOUTUBE = "YouTube"


class PostStatus:
    DRAFT = "DRAFT"
    SCHEDULED = "SCHEDULED"
    PUBLISHED = "PUBLISHED"
    FAILED = "FAILED"


class SocialAccount(db.Model):
    __tablename__ = "social_accounts"

    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey("clients.id"), nullable=False)
    platform = db.Column(db.String(64), nullable=False)
    account_handle = db.Column(db.String(128), nullable=False)
    account_name = db.Column(db.String(128), nullable=True)
    is_connected = db.Column(db.Boolean, default=True, nullable=False)
    follower_count = db.Column(db.Integer, default=0, nullable=False)
    reach_count = db.Column(db.Integer, default=0, nullable=False)
    engagement_rate = db.Column(db.Float, default=0.0, nullable=False)
    avatar_url = db.Column(db.String(256), nullable=True)
    connected_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = db.Column(
        db.DateTime,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False
    )

    client = db.relationship("Client", back_populates="social_accounts")
    posts = db.relationship("SocialPost", back_populates="account")

    def __repr__(self):
        return f"<SocialAccount {self.platform}: {self.account_handle}>"


class SocialPost(db.Model):
    __tablename__ = "social_posts"

    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey("clients.id"), nullable=False)
    account_id = db.Column(db.Integer, db.ForeignKey("social_accounts.id"), nullable=True)
    campaign_id = db.Column(db.Integer, db.ForeignKey("campaigns.id"), nullable=True)
    platform = db.Column(db.String(64), nullable=False)
    caption = db.Column(db.Text, nullable=False)
    hashtags = db.Column(db.Text, nullable=True)
    media_url = db.Column(db.String(512), nullable=True)
    media_type = db.Column(db.String(32), default="IMAGE")  # IMAGE, VIDEO, CAROUSEL, TEXT
    status = db.Column(db.String(32), default=PostStatus.DRAFT, nullable=False)
    scheduled_time = db.Column(db.DateTime, nullable=True)
    published_time = db.Column(db.DateTime, nullable=True)
    likes = db.Column(db.Integer, default=0, nullable=False)
    comments = db.Column(db.Integer, default=0, nullable=False)
    shares = db.Column(db.Integer, default=0, nullable=False)
    impressions = db.Column(db.Integer, default=0, nullable=False)
    reach = db.Column(db.Integer, default=0, nullable=False)
    clicks = db.Column(db.Integer, default=0, nullable=False)
    engagement_rate = db.Column(db.Float, default=0.0, nullable=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = db.Column(
        db.DateTime,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False
    )

    client = db.relationship("Client", back_populates="social_posts")
    account = db.relationship("SocialAccount", back_populates="posts")
    campaign = db.relationship("Campaign", back_populates="posts")

    # Compatibility aliases
    @hybrid_property
    def content_text(self) -> str:
        return self.caption

    @content_text.setter
    def content_text(self, val: str):
        self.caption = val

    @hybrid_property
    def scheduled_for(self):
        return self.scheduled_time

    @scheduled_for.setter
    def scheduled_for(self, val):
        self.scheduled_time = val

    @property
    def performance_reach(self) -> int:
        return self.reach

    @property
    def performance_likes(self) -> int:
        return self.likes

    def __repr__(self):
        return f"<SocialPost {self.id} on {self.platform} ({self.status})>"

