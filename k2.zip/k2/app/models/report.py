from datetime import date, datetime, timezone
from app.extensions import db


class ReportType:
    WEEKLY = "WEEKLY"
    MONTHLY = "MONTHLY"
    CAMPAIGN = "CAMPAIGN"
    CUSTOM = "CUSTOM"


class Report(db.Model):
    __tablename__ = "reports"

    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey("clients.id"), nullable=False)
    title = db.Column(db.String(256), nullable=False)
    report_type = db.Column(db.String(32), default=ReportType.WEEKLY, nullable=False)
    period_start = db.Column(db.Date, nullable=False, default=date.today)
    period_end = db.Column(db.Date, nullable=False, default=date.today)
    summary = db.Column(db.Text, nullable=True)
    metrics_json = db.Column(db.JSON, default=dict)
    recommendations_json = db.Column(db.JSON, default=list)
    campaigns_json = db.Column(db.JSON, default=list)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)

    client = db.relationship("Client", back_populates="reports")

    def __repr__(self):
        return f"<Report {self.title} ({self.report_type})>"


class MarketResearch(db.Model):
    __tablename__ = "market_researches"

    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey("clients.id"), nullable=False)
    industry = db.Column(db.String(64), nullable=False)
    target_audience = db.Column(db.Text, nullable=False)
    competitor_analysis_json = db.Column(db.JSON, default=dict)
    trends_json = db.Column(db.JSON, default=list)
    consumer_insights = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)

    def __repr__(self):
        return f"<MarketResearch for Industry: {self.industry}>"

