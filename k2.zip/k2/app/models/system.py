from datetime import datetime, timezone
from app.extensions import db


class Notification(db.Model):
    __tablename__ = "notifications"

    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey("clients.id"), nullable=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)
    title = db.Column(db.String(128), nullable=False)
    message = db.Column(db.Text, nullable=False)
    type = db.Column(db.String(32), default="INFO")  # INFO, SUCCESS, WARNING, DANGER
    is_read = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)

    def __repr__(self):
        return f"<Notification '{self.title}'>"


class ScheduledTask(db.Model):
    __tablename__ = "scheduled_tasks"

    id = db.Column(db.Integer, primary_key=True)
    task_name = db.Column(db.String(128), nullable=False)
    payload_json = db.Column(db.JSON, default=dict)
    scheduled_at = db.Column(db.DateTime, nullable=False)
    status = db.Column(db.String(32), default="PENDING", nullable=False)  # PENDING, RUNNING, COMPLETED, FAILED
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)

    def __repr__(self):
        return f"<ScheduledTask {self.task_name} ({self.status})>"


class Integration(db.Model):
    __tablename__ = "integrations"

    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey("clients.id"), nullable=False)
    provider = db.Column(db.String(64), nullable=False)  # Meta, Google, LinkedIn, OpenAI, Mailchimp
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    credentials_json = db.Column(db.JSON, default=dict)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)

    def __repr__(self):
        return f"<Integration {self.provider} (Active: {self.is_active})>"


class AutomationRule(db.Model):
    __tablename__ = "automation_rules"

    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey("clients.id"), nullable=False)
    name = db.Column(db.String(128), nullable=False)
    event_trigger = db.Column(db.String(64), nullable=False)
    condition_json = db.Column(db.JSON, default=dict)
    action_type = db.Column(db.String(64), nullable=False)
    action_payload_json = db.Column(db.JSON, default=dict)
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    last_triggered_at = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)

    client = db.relationship("Client", back_populates="automation_rules")

    def __repr__(self):
        return f"<AutomationRule '{self.name}'>"

