from datetime import datetime, timezone
from app.extensions import db


class ContentType:
    POST = "POST"
    ARTICLE = "ARTICLE"
    AD_COPY = "AD_COPY"
    EMAIL = "EMAIL"
    VIDEO_SCRIPT = "VIDEO_SCRIPT"


class CreativeType:
    IMAGE = "IMAGE"
    VIDEO = "VIDEO"
    STORYBOARD = "STORYBOARD"
    BANNER = "BANNER"


class Content(db.Model):
    __tablename__ = "contents"

    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey("clients.id"), nullable=False)
    title = db.Column(db.String(256), nullable=False)
    content_type = db.Column(db.String(32), default=ContentType.POST, nullable=False)
    body = db.Column(db.Text, nullable=False)
    channel = db.Column(db.String(64), nullable=True)
    status = db.Column(db.String(32), default="DRAFT", nullable=False)
    ai_generated = db.Column(db.Boolean, default=True, nullable=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = db.Column(
        db.DateTime,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False
    )

    client = db.relationship("Client", back_populates="content_items")

    def __repr__(self):
        return f"<Content {self.title} ({self.content_type})>"


class Creative(db.Model):
    __tablename__ = "creatives"

    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey("clients.id"), nullable=False)
    title = db.Column(db.String(256), nullable=False)
    creative_type = db.Column(db.String(32), default=CreativeType.IMAGE, nullable=False)
    asset_url = db.Column(db.String(512), nullable=False)
    dimensions = db.Column(db.String(64), default="1080x1080")
    format = db.Column(db.String(16), default="PNG")
    prompt_used = db.Column(db.Text, nullable=True)
    metadata_json = db.Column(db.JSON, default=dict)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)

    client = db.relationship("Client", back_populates="creatives")

    def __repr__(self):
        return f"<Creative {self.title} ({self.creative_type})>"

