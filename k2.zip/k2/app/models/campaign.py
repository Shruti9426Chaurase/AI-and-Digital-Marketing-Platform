from datetime import date, datetime, timezone
from sqlalchemy.ext.hybrid import hybrid_property
from app.extensions import db


class CampaignStatus:
    DRAFT = "DRAFT"
    SCHEDULED = "SCHEDULED"
    ACTIVE = "ACTIVE"
    PAUSED = "PAUSED"
    COMPLETED = "COMPLETED"


class CampaignObjective:
    BRAND_AWARENESS = "Brand Awareness"
    LEAD_GENERATION = "Lead Generation"
    SALES = "Sales"
    TRAFFIC = "Traffic"
    ENGAGEMENT = "Engagement"


class Campaign(db.Model):
    __tablename__ = "campaigns"

    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey("clients.id"), nullable=False)
    name = db.Column(db.String(128), nullable=False)
    objective = db.Column(db.String(64), default=CampaignObjective.BRAND_AWARENESS, nullable=False)
    status = db.Column(db.String(32), default=CampaignStatus.ACTIVE, nullable=False)
    budget = db.Column(db.Float, default=0.0, nullable=False)
    spend = db.Column(db.Float, default=0.0, nullable=False)
    start_date = db.Column(db.Date, default=date.today, nullable=False)
    end_date = db.Column(db.Date, nullable=True)
    target_audience_desc = db.Column(db.Text, nullable=True)
    platforms_json = db.Column(db.JSON, default=list)
    ai_recommendations_summary = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = db.Column(
        db.DateTime,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False
    )

    client = db.relationship("Client", back_populates="campaigns")
    metrics = db.relationship("CampaignMetric", back_populates="campaign", cascade="all, delete-orphan")
    posts = db.relationship("SocialPost", back_populates="campaign")

    def __repr__(self):
        return f"<Campaign {self.name} ({self.status})>"


class CampaignMetric(db.Model):
    __tablename__ = "campaign_metrics"

    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey("clients.id"), nullable=False)
    campaign_id = db.Column(db.Integer, db.ForeignKey("campaigns.id"), nullable=True)
    date = db.Column(db.Date, default=date.today, nullable=False)
    platform = db.Column(db.String(64), default="Meta Ads", nullable=False)
    data_source = db.Column(db.String(32), default="API", nullable=False)  # API, MANUAL, DEMO
    impressions = db.Column(db.Integer, default=0, nullable=False)
    reach = db.Column(db.Integer, default=0, nullable=False)
    clicks = db.Column(db.Integer, default=0, nullable=False)
    conversions = db.Column(db.Integer, default=0, nullable=False)
    spend = db.Column(db.Float, default=0.0, nullable=False)
    revenue = db.Column(db.Float, default=0.0, nullable=False)
    likes = db.Column(db.Integer, default=0, nullable=False)
    comments = db.Column(db.Integer, default=0, nullable=False)
    shares = db.Column(db.Integer, default=0, nullable=False)
    website_visitors = db.Column(db.Integer, default=0, nullable=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)

    campaign = db.relationship("Campaign", back_populates="metrics")

    @hybrid_property
    def channel(self) -> str:
        return self.platform

    @channel.setter
    def channel(self, val: str):
        self.platform = val

    @property
    def ctr(self) -> float:
        """Click-Through Rate (%)"""
        return round((self.clicks / self.impressions * 100), 2) if self.impressions > 0 else 0.0

    @property
    def cpc(self) -> float:
        """Cost Per Click (₹)"""
        return round((self.spend / self.clicks), 2) if self.clicks > 0 else 0.0

    @property
    def cpa(self) -> float:
        """Cost Per Acquisition / Lead (₹)"""
        return round((self.spend / self.conversions), 2) if self.conversions > 0 else 0.0

    @property
    def roas(self) -> float:
        """Return on Ad Spend (multiplier, e.g. 5.0x)"""
        return round((self.revenue / self.spend), 2) if self.spend > 0 else 0.0

    @property
    def roi(self) -> float:
        """Return on Investment (%)"""
        return round(((self.revenue - self.spend) / self.spend * 100), 2) if self.spend > 0 else 0.0

    @property
    def engagement_rate(self) -> float:
        """Engagement Rate (%)"""
        total_eng = self.likes + self.comments + self.shares
        if total_eng > 0 and self.reach > 0:
            return round((total_eng / self.reach * 100), 2)
        elif (self.clicks + self.conversions) > 0 and self.reach > 0:
            return round(((self.clicks + self.conversions) / self.reach * 100), 2)
        return 0.0

    def __repr__(self):
        return f"<CampaignMetric {self.platform} on {self.date} (Spend: {self.spend}, Rev: {self.revenue})>"


class Audience(db.Model):
    __tablename__ = "audiences"

    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey("clients.id"), nullable=False)
    name = db.Column(db.String(128), nullable=False)
    description = db.Column(db.Text, nullable=True)
    demographics_json = db.Column(db.JSON, default=dict)
    interests_json = db.Column(db.JSON, default=list)
    size_estimate = db.Column(db.Integer, default=500000)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)

    def __repr__(self):
        return f"<Audience {self.name}>"

