from datetime import datetime, timezone
from app.extensions import db


class Client(db.Model):
    __tablename__ = "clients"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, unique=True)
    company_name = db.Column(db.String(128), nullable=False)
    industry = db.Column(db.String(64), default="Digital Marketing")
    tier = db.Column(db.String(32), default="Growth")  # Starter, Growth, Enterprise
    status = db.Column(db.String(32), default="Active")  # Active, Inactive, Pending
    website = db.Column(db.String(256), nullable=True)
    phone = db.Column(db.String(32), nullable=True)
    address = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = db.Column(
        db.DateTime,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False
    )

    # Relationships
    user = db.relationship("User", back_populates="client")
    brand_kit = db.relationship("BrandKit", uselist=False, back_populates="client", cascade="all, delete-orphan")
    campaigns = db.relationship("Campaign", back_populates="client", cascade="all, delete-orphan")
    social_accounts = db.relationship("SocialAccount", back_populates="client", cascade="all, delete-orphan")
    social_posts = db.relationship("SocialPost", back_populates="client", cascade="all, delete-orphan")
    leads = db.relationship("Lead", back_populates="client", cascade="all, delete-orphan")
    customers = db.relationship("Customer", back_populates="client", cascade="all, delete-orphan")
    seo_projects = db.relationship("SEOProject", back_populates="client", cascade="all, delete-orphan")
    ai_conversations = db.relationship("AIConversation", back_populates="client", cascade="all, delete-orphan")
    recommendations = db.relationship("Recommendation", back_populates="client", cascade="all, delete-orphan")
    reports = db.relationship("Report", back_populates="client", cascade="all, delete-orphan")
    content_items = db.relationship("Content", back_populates="client", cascade="all, delete-orphan")
    creatives = db.relationship("Creative", back_populates="client", cascade="all, delete-orphan")
    automation_rules = db.relationship("AutomationRule", back_populates="client", cascade="all, delete-orphan")

    def __repr__(self):
        return f"<Client {self.company_name} (ID: {self.id})>"


class BrandKit(db.Model):
    __tablename__ = "brand_kits"

    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey("clients.id"), nullable=False, unique=True)
    brand_name = db.Column(db.String(128), nullable=False)
    tagline = db.Column(db.String(256), nullable=True)
    target_audience = db.Column(db.Text, nullable=True)
    primary_color = db.Column(db.String(16), default="#FFC72C")
    secondary_color = db.Column(db.String(16), default="#EF4444")
    font_family = db.Column(db.String(64), default="Inter, sans-serif")
    voice_tone = db.Column(db.String(64), default="Bold, energetic, authoritative")
    logo_url = db.Column(db.String(256), nullable=True)
    brand_guidelines = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = db.Column(
        db.DateTime,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False
    )

    client = db.relationship("Client", back_populates="brand_kit")

    def __repr__(self):
        return f"<BrandKit {self.brand_name}>"

