from datetime import datetime, timezone
from sqlalchemy.ext.hybrid import hybrid_property
from app.extensions import db


class RecommendationPriority:
    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"


class RecommendationStatus:
    PENDING = "PENDING"
    ACCEPTED = "ACCEPTED"
    APPLIED = "APPLIED"
    DISMISSED = "DISMISSED"


class ActionStatus:
    NONE = "NONE"
    PENDING = "PENDING"
    CONFIRMATION_REQUIRED = "CONFIRMATION_REQUIRED"
    CONFIRMED = "CONFIRMED"
    SCHEDULED = "SCHEDULED"
    CANCELLED = "CANCELLED"
    EXECUTED = "EXECUTED"


class AIConversation(db.Model):
    __tablename__ = "ai_conversations"

    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey("clients.id"), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    title = db.Column(db.String(128), default="Marketing Strategy Session", nullable=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = db.Column(
        db.DateTime,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False
    )

    client = db.relationship("Client", back_populates="ai_conversations")
    messages = db.relationship(
        "AIMessage",
        back_populates="conversation",
        cascade="all, delete-orphan",
        order_by="AIMessage.created_at"
    )

    def __repr__(self):
        return f"<AIConversation {self.id}: {self.title}>"


class AIMessage(db.Model):
    __tablename__ = "ai_messages"

    id = db.Column(db.Integer, primary_key=True)
    conversation_id = db.Column(db.Integer, db.ForeignKey("ai_conversations.id"), nullable=False)
    sender = db.Column(db.String(16), nullable=False)  # "user" or "assistant"
    content = db.Column(db.Text, nullable=False)
    action_required = db.Column(db.Boolean, default=False, nullable=False)
    action_type = db.Column(db.String(64), nullable=True)  # e.g., "SCHEDULE_POSTS", "REALLOCATE_BUDGET"
    action_payload = db.Column(db.JSON, nullable=True)
    action_status = db.Column(db.String(32), default=ActionStatus.NONE, nullable=True)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)

    conversation = db.relationship("AIConversation", back_populates="messages")

    @property
    def action_payload_json(self):
        return self.action_payload

    @action_payload_json.setter
    def action_payload_json(self, value):
        self.action_payload = value

    def __repr__(self):
        return f"<AIMessage {self.sender} ({self.id})>"


class Recommendation(db.Model):
    __tablename__ = "recommendations"

    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey("clients.id"), nullable=False)
    title = db.Column(db.String(256), nullable=False)
    description = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(64), default="Performance", nullable=False)
    priority = db.Column(db.String(16), default=RecommendationPriority.MEDIUM, nullable=False)
    confidence = db.Column(db.Integer, default=85, nullable=False)
    projected_impact = db.Column(db.String(128), nullable=True)
    status = db.Column(db.String(32), default=RecommendationStatus.PENDING, nullable=False)
    action_code = db.Column(db.String(64), nullable=True)
    action_payload = db.Column(db.JSON, nullable=True)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = db.Column(
        db.DateTime,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False
    )

    client = db.relationship("Client", back_populates="recommendations")

    @hybrid_property
    def confidence_score(self) -> int:
        return self.confidence

    @confidence_score.setter
    def confidence_score(self, value: int):
        self.confidence = value

    @property
    def action_payload_json(self):
        return self.action_payload

    @action_payload_json.setter
    def action_payload_json(self, value):
        self.action_payload = value

    def __repr__(self):
        return f"<Recommendation '{self.title}' ({self.priority})>"

