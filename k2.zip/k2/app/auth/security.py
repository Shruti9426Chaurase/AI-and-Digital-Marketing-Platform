from functools import wraps
from flask import abort, redirect, url_for, flash, request
from flask_login import current_user
from app.extensions import db
from app.models.user import UserRole, AuditLog
from app.models.client import Client


def role_required(*roles):
    """Decorator to enforce role-based access control."""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.is_authenticated:
                flash("Please log in to access this page.", "warning")
                return redirect(url_for("auth.login", next=request.url))
            if current_user.role not in roles:
                flash("Access denied: You do not have permission to view this resource.", "danger")
                abort(403)
            return f(*args, **kwargs)
        return decorated_function
    return decorator


def admin_required(f):
    """Enforces Admin-only access."""
    return role_required(UserRole.ADMIN)(f)


def manager_or_admin_required(f):
    """Enforces Marketing Manager or Admin access."""
    return role_required(UserRole.ADMIN, UserRole.MARKETING_MANAGER)(f)


def get_current_client():
    """
    Resolves the active Client entity for the current session.
    - If user is a CLIENT, returns their assigned workspace.
    - If user is an ADMIN or MANAGER, allows switching via ?client_id= or defaults to the primary client.
    """
    if not current_user.is_authenticated:
        return None

    # Check for explicit switch in query params (for Admins / Managers)
    requested_client_id = request.args.get("client_id", type=int)
    if requested_client_id and current_user.is_manager:
        client = db.session.get(Client, requested_client_id)
        if client:
            return client

    # Client associated directly with current user
    user_client = Client.query.filter_by(user_id=current_user.id).first()
    if user_client:
        return user_client

    # Admin/Manager fallback: return first active client
    if current_user.is_manager:
        return Client.query.first()

    return None


def log_audit_action(action: str, details: str = None, ip_address: str = None):
    """Records an audit log entry for administrative & security actions."""
    try:
        user_id = current_user.id if (current_user and current_user.is_authenticated) else None
        ip = ip_address or (request.remote_addr if request else "127.0.0.1")
        log = AuditLog(
            user_id=user_id,
            action=action,
            details=details,
            ip_address=ip
        )
        db.session.add(log)
        db.session.commit()
    except Exception as e:
        db.session.rollback()

