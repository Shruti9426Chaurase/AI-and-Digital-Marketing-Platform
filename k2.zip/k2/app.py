
import os
import sys

# Ensure UTF-8 output on Windows consoles
if sys.stdout and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

if sys.stderr and hasattr(sys.stderr, "reconfigure"):
    try:
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

# Ensure base directory is in sys.path
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from app import create_app, auto_initialize_and_seed
from app.extensions import db
from app.models.user import User

# Create the application instance
app = create_app(os.environ.get("FLASK_ENV", "development"))


def run_init():
    """Ensures database tables are created and demo accounts are present."""
    with app.app_context():
        db.create_all()
        admin_user = User.query.filter_by(email="admin@backkbenchers.com").first()
        if not admin_user:
            print("\n" + "=" * 65)
            print("  [*] BACKKBENCHERS: Initializing tables & seeding demo data...")
            print("=" * 65)
            from scripts.seed_demo_data import run_seed
            run_seed()
            print("=" * 65)


if __name__ == "__main__":
    run_init()

    port = int(os.environ.get("PORT", 5000))
    host = os.environ.get("HOST", "127.0.0.1")

    print("\n" + "=" * 65)
    print("  >>> BACKKBENCHERS AI Marketing Platform is LIVE! <<<")
    print("=" * 65)
    print(f"  [+] Public Marketing Website : http://{host}:{port}/")
    print(f"  [+] Client SaaS Dashboard    : http://{host}:{port}/dashboard/")
    print(f"  [+] Admin Master Console     : http://{host}:{port}/admin/")
    print(f"  [+] Login Page               : http://{host}:{port}/auth/login")
    print("-" * 65)
    print("  Demo Logins (Click 'Quick Demo Fill' buttons on login page):")
    print("    - Admin   : admin@backkbenchers.com   / Admin@1234")
    print("    - Manager : manager@backkbenchers.com / Manager@1234")
    print("    - Client  : client@backkbenchers.com  / Client@1234")
    print("=" * 65 + "\n")

    # Start Flask development server
    app.run(host=host, port=port, debug=True)