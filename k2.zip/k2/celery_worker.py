import os
from celery import Celery
from celery.schedules import crontab
from datetime import datetime, timezone

from app import create_app
from app.extensions import db
from app.models.social import SocialPost, PostStatus
from app.services.social_service import SocialService
from app.services.report_service import ReportService
from app.services.seo_service import SEOService
from app.models.client import Client

flask_app = create_app(os.environ.get("FLASK_ENV", "development"))

def make_celery(app):
    celery = Celery(
        app.import_name,
        broker=app.config["CELERY_BROKER_URL"],
        backend=app.config["CELERY_RESULT_BACKEND"]
    )
    celery.conf.update(app.config)

    class ContextTask(celery.Task):
        def __call__(self, *args, **kwargs):
            with app.app_context():
                return self.run(*args, **kwargs)

    celery.Task = ContextTask
    return celery

celery = make_celery(flask_app)

# Celery Beat Scheduled Tasks
celery.conf.beat_schedule = {
    "publish-due-posts-every-minute": {
        "task": "celery_worker.publish_due_posts_task",
        "schedule": 60.0,
    },
    "weekly-marketing-reports-monday": {
        "task": "celery_worker.generate_weekly_reports_task",
        "schedule": crontab(hour=9, minute=0, day_of_week=1),
    }
}
celery.conf.timezone = "Asia/Kolkata"


@celery.task
def publish_due_posts_task():
    """Checks for posts that have reached their scheduled time and executes publishing."""
    now_utc = datetime.now(timezone.utc)
    due_posts = SocialPost.query.filter(
        SocialPost.status == PostStatus.SCHEDULED,
        SocialPost.scheduled_for <= now_utc
    ).all()

    published_count = 0
    for p in due_posts:
        res = SocialService.publish_post_now(p.id)
        if res.get("status") == PostStatus.PUBLISHED:
            published_count += 1

    return f"Processed {len(due_posts)} due posts. Published: {published_count}."


@celery.task
def generate_weekly_reports_task():
    """Generates Monday executive reports for all active clients."""
    clients = Client.query.filter_by(status="Active").all()
    count = 0
    for cl in clients:
        ReportService.generate_report(cl.id, period_days=7)
        count += 1
    return f"Generated {count} weekly reports."


@celery.task
def run_periodic_seo_checks_task(project_id: int):
    """Executes background SEO crawl."""
    res = SEOService.run_audit(project_id)
    return f"SEO audit completed for Project #{project_id} with score {res.get('score')}."

