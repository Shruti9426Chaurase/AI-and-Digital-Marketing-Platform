# BACKKBENCHERS — AI-Powered Digital Marketing SaaS Platform

> **"AI-powered marketing that turns brands into marketing machines."**

A complete, enterprise-grade, deployable full-stack SaaS platform and agency operations engine built for **BACKKBENCHERS**. It unifies high-velocity creative production, multi-channel performance advertising, an autonomous conversational AI Marketing Agent with confirmation-gated execution, automated post scheduling, hybrid analytics (API + Manual CSV entry), an SEO suite, CRM lead scoring, and an event-driven automation rules engine.

---

## Key Highlights & Capabilities

- **Public Marketing Website**: 10 responsive public pages (Home, About, Services, AI Studio, Portfolio, Case Studies, Pricing, Contact, Blog, Get Started) reflecting the signature BackkBenchers brand identity (Vibrant Gold/Yellow `#FFC72C`, Crimson `#EF4444`, Onyx Black `#0B0F19`, and Clean Canvas `#FFFFFF`).
- **SaaS Dashboards**: Role-based access control (Admin, Marketing Manager, Client, Employee) with strict multi-tenant workspace isolation.
- **Autonomous AI Marketing Agent**: Conversational chat interface backed by conversation memory and actionable tool integrations. It diagnoses performance anomalies, plans campaigns, and executes confirmation-gated operations (`[Schedule All]`, `[Review]`, `[Cancel]`).
- **Hybrid Analytics Engine**: Unified reporting that integrates live API metrics, manual dashboard entries, and bulk CSV uploads with automated calculations for CTR, CPC, CPA, ROAS, and ROI.
- **Centralized Social Media**: Visual content calendar with Monthly/Weekly/Daily views, scheduled publishing via Celery + Redis, and clear manual publishing workflows for disconnected channels.
- **AI Creative Studio & Video Storyboard**: Multi-format design engine (Instagram 1:1, Stories 9:16, LinkedIn Banners, YouTube Thumbnails, Metro Pillars, Highway Billboards, Newspaper Jackets) with 3-scene video storyboard generation.
- **Leads CRM & AI Scoring**: Automatic lead classification into `Hot`, `Warm`, and `Cold` with explainable scoring rationales and pipeline conversion tracking.
- **Automation Rules Engine**: Event-driven automation triggers (`IF engagement drops > 15% THEN recommend action`, `IF budget limit reached THEN pause campaign`).
- **Deployment Ready**: Fully containerized with Docker, `docker-compose.yml` (App + Postgres + Redis + Celery Worker + Celery Beat), `Procfile`, and zero-crash SQLite fallback for local developer setups.

---

## Technology Stack

- **Backend**: Python 3.12+, Flask 3.0+, Flask-SQLAlchemy, Flask-Migrate, Flask-Login, Flask-WTF, Werkzeug, Gunicorn
- **Database**: PostgreSQL 16 (Production) / SQLite3 (Zero-config local fallback)
- **Frontend**: HTML5, CSS3, Jinja2, Bootstrap 5.3, BackkBenchers Design System CSS, Chart.js 4.4, DataTables, FontAwesome 6
- **Asynchronous Tasks & Scheduling**: Celery 5.4, Redis 7
- **AI Integration**: Pluggable provider architecture (`app/services/ai_service.py`) supporting OpenAI API, Google Gemini, and a built-in Heuristic Marketing Engine that guarantees 100% functionality offline without API keys.
- **Data Processing**: Pandas, OpenPyXL, Pillow

---

## Project Structure

```
backkbenchers/
├── app/
│   ├── __init__.py                 # Application Factory, error handlers & context
│   ├── config.py                   # Multi-environment configuration
│   ├── extensions.py               # SQLAlchemy, Migrate, LoginManager, CSRF
│   │
│   ├── models/                     # 22 Normalized Database Entities
│   │   ├── __init__.py
│   │   ├── user.py                 # User, UserRole, AuditLog
│   │   ├── client.py               # Client, BrandKit
│   │   ├── social.py               # SocialAccount, SocialPost
│   │   ├── campaign.py             # Campaign, CampaignMetric, Audience
│   │   ├── content.py              # Content, Creative
│   │   ├── seo.py                  # SEOProject, SEOKeyword
│   │   ├── lead.py                 # Lead, Customer
│   │   ├── ai.py                   # AIConversation, AIMessage, Recommendation
│   │   ├── report.py               # Report, MarketResearch
│   │   └── system.py               # Notification, ScheduledTask, AutomationRule
│   │
│   ├── auth/                       # Authentication & Security
│   │   ├── forms.py                # Flask-WTF Forms with validation
│   │   └── security.py             # RBAC Decorators & Audit Loggers
│   │
│   ├── routes/                     # Blueprint Handlers
│   │   ├── public_routes.py        # Marketing site & Lead capture
│   │   ├── auth_routes.py          # Login, Register, Password Reset
│   │   ├── client_routes.py        # SaaS Client Dashboard (18 Views)
│   │   ├── admin_routes.py         # Admin Master Console
│   │   └── api_routes.py           # REST APIs
│   │
│   ├── services/                   # Business Logic & Service Layer
│   │   ├── ai_service.py           # Conversational Agent & Tools
│   │   ├── analytics_service.py    # Hybrid Data & CSV Parser
│   │   ├── social_service.py       # Social Accounts & Post Publishing
│   │   ├── campaign_service.py     # 10-Step Wizard & ROAS Rebalancer
│   │   ├── seo_service.py          # Technical Audit & Keyword Tracking
│   │   ├── lead_service.py         # CRM Pipeline & Lead Scoring
│   │   ├── report_service.py       # Report Assembly & CSV Export
│   │   └── automation_service.py   # Event Triggers & Rule Dispatcher
│   │
│   ├── templates/
│   │   ├── base/                   # Base & Dashboard Master Layouts
│   │   ├── public/                 # 10 Public Pages
│   │   ├── auth/                   # Auth & Profile Pages
│   │   ├── client/                 # 17 SaaS Client Views
│   │   ├── admin/                  # 4 Admin Management Views
│   │   └── errors/                 # 400, 403, 404, 429, 500
│   │
│   └── static/
│       ├── css/backkbenchers.css   # Master Brand Design System
│       ├── js/main.js              # Client Utilities & CSRF Helpers
│       └── uploads/                # File Storage Abstraction
│
├── scripts/
│   └── seed_demo_data.py           # Realistic Demo Data Seeder
├── tests/                          # Automated Pytest Suite
├── celery_worker.py                # Celery Worker & Beat Scheduler
├── Dockerfile                      # Production Container
├── docker-compose.yml              # Complete Multi-Container Stack
├── Procfile                        # PaaS Deployment Entrypoint
├── requirements.txt                # Pinned Dependencies
├── .env.example                    # Environment Template
├── run.py                          # Local Development Entrypoint
└── README.md
```

---

## Installation & Setup Guide

### 1. Clone & Environment Setup

#### Windows:
```powershell
python -m venv venv
.\venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

#### macOS / Linux:
```bash
python3 -m venv venv
source venv/bin/activate
python3 -m pip install --upgrade pip
pip install -r requirements.txt
```

### 2. Environment Variables Configuration

Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```

Default `.env` settings for instant local execution:
```ini
FLASK_APP=run.py
FLASK_ENV=development
SECRET_KEY=backkbenchers-development-secret-key-12345
DATABASE_URL=sqlite:///backkbenchers.db
AI_PROVIDER=mock
DEMO_MODE=True
```

### 3. Initialize Database & Seed Realistic Demo Data

Run the CLI seed command:
```bash
python run.py seed-demo
```
This automatically initializes all 22 database tables and populates realistic demo accounts, active campaigns, 30 days of metrics, social accounts, SEO keywords, leads, and AI recommendations.

### 4. Run the Application Locally

```bash
python run.py
```
Open your browser and navigate to: **http://127.0.0.1:5000**

---

## Demo Credentials

The platform comes pre-configured with demo accounts for each role:

| Role | Email | Password | Access Level |
| :--- | :--- | :--- | :--- |
| **Director / Admin** | `admin@backkbenchers.com` | `Admin@1234` | Full system control, all clients, audit logs |
| **Marketing Manager**| `manager@backkbenchers.com`| `Manager@1234`| Campaign approvals, client overviews |
| **Client Owner** | `client@backkbenchers.com` | `Client@1234` | Private workspace (AeroFit Activewear) |

*Tip: The login page at `/auth/login` includes one-click "Quick Demo Fill" buttons for instant testing.*

---

## Running Background Tasks (Celery + Redis)

For production scheduled posts, automated report generation, and periodic SEO checks:

### Start Redis:
```bash
# Docker
docker run -d -p 6379:6379 redis:7-alpine

# Linux/macOS
redis-server
```

### Start Celery Worker:
```bash
celery -A celery_worker.celery worker --loglevel=info
```

### Start Celery Beat Scheduler:
```bash
celery -A celery_worker.celery beat --loglevel=info
```

*Note: The platform features a resilient built-in synchronous dispatcher. If Redis/Celery is not running locally, the application continues to run without crashing.*

---

## Running Automated Tests

Execute the comprehensive test suite with `pytest`:

```bash
pytest tests/ -v
```

Tests cover:
- Authentication, password hashing, and role-based access control
- Conversational AI Marketing Agent and confirmation-gated action execution
- Hybrid metric calculations (CTR, CPC, CPA, ROAS, ROI) and CSV imports
- 10-step campaign creation wizard and lead CRM scoring
- REST API health and data endpoints

---

## Production Deployment

### Docker Compose (Recommended)

To deploy the entire production stack (Flask + Gunicorn + PostgreSQL + Redis + Celery Worker + Celery Beat):

```bash
docker-compose up --build -d
```
Access the application at `http://localhost:5000`.

### Cloud PaaS (Render / Railway / AWS Elastic Beanstalk)

1. Connect your repository to Render or Railway.
2. Set Build Command: `pip install -r requirements.txt`
3. Set Start Command: `gunicorn run:app --bind 0.0.0.0:$PORT --workers 4 --threads 2`
4. Add environment variables:
   - `DATABASE_URL`: Your production PostgreSQL connection string
   - `REDIS_URL`: Your production Redis connection string
   - `SECRET_KEY`: A high-entropy random string
   - `AI_PROVIDER`: `openai` or `gemini` (optional)
   - `OPENAI_API_KEY`: Your OpenAI API key (optional)

---

## REST API Documentation

All endpoints return standard JSON structures.

| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/api/health` | Container health probe & status check |
| `GET` | `/api/dashboard` | Overview KPIs (`client_id`, `days`) |
| `GET` | `/api/social/accounts`| List connected social channels |
| `POST`| `/api/social/posts` | Create or schedule a social post |
| `GET` | `/api/campaigns` | List active marketing campaigns |
| `POST`| `/api/campaigns` | Create a new campaign programmatically |
| `POST`| `/api/ai/chat` | Send prompt to conversational AI Agent |
| `POST`| `/api/ai/generate-content`| Generate specialized marketing copy |
| `GET` | `/api/leads` | Retrieve lead CRM records |
| `POST`| `/api/leads` | Ingest external leads with automated AI scoring |
| `GET` | `/api/seo` | SEO project health score & keyword rankings |
| `POST`| `/api/reports` | Trigger automated marketing report assembly |

---

## Brand Identity & Color Tokens

- **Primary Yellow**: `#FFC72C`
- **Accent Viral Red**: `#EF4444`
- **Dark Onyx Base**: `#0B0F19`
- **Card Dark Surface**: `#111827`
- **Body Canvas Light**: `#F8FAFC`

---

## License & Intellectual Property

&copy; 2026 **BACKKBENCHERS Media Private Limited**. All Rights Reserved.
Built as an enterprise-grade AI marketing SaaS and digital agency operations platform.

