import os
import sys
from datetime import date, datetime, timedelta, timezone

# Ensure project root is in python path
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from app.extensions import db
from app.models.user import User, UserRole
from app.models.client import Client, BrandKit
from app.models.social import SocialAccount, SocialPost, SocialPlatform, PostStatus
from app.models.campaign import Campaign, CampaignMetric, CampaignStatus, CampaignObjective, Audience
from app.models.content import Content, Creative, ContentType, CreativeType
from app.models.seo import SEOProject, SEOKeyword
from app.models.lead import Lead, Customer, LeadStatus, LeadScore
from app.models.ai import (
    AIConversation, AIMessage, Recommendation,
    RecommendationPriority, RecommendationStatus, ActionStatus
)
from app.models.report import Report, ReportType, MarketResearch
from app.models.system import Notification, AutomationRule


def run_seed():
    """Idempotently seeds production-grade demo data for BackkBenchers."""
    print("  -> Creating / verifying users...")

    # 1. Admin User
    admin = User.query.filter_by(email="admin@backkbenchers.com").first()
    if not admin:
        admin = User(
            email="admin@backkbenchers.com",
            first_name="Agency",
            last_name="Director",
            role=UserRole.ADMIN,
            is_active=True,
            is_verified=True,
            last_login_at=datetime.now(timezone.utc)
        )
        admin.set_password("Admin@1234")
        db.session.add(admin)

    # 2. Marketing Manager User
    manager = User.query.filter_by(email="manager@backkbenchers.com").first()
    if not manager:
        manager = User(
            email="manager@backkbenchers.com",
            first_name="Rohan",
            last_name="Kapoor",
            role=UserRole.MARKETING_MANAGER,
            is_active=True,
            is_verified=True,
            last_login_at=datetime.now(timezone.utc)
        )
        manager.set_password("Manager@1234")
        db.session.add(manager)

    # 3. Client User
    client_user = User.query.filter_by(email="client@backkbenchers.com").first()
    if not client_user:
        client_user = User(
            email="client@backkbenchers.com",
            first_name="Aditya",
            last_name="Singhania",
            role=UserRole.CLIENT,
            is_active=True,
            is_verified=True,
            last_login_at=datetime.now(timezone.utc)
        )
        client_user.set_password("Client@1234")
        db.session.add(client_user)

    db.session.commit()

    # 4. Client Workspace (AeroFit Activewear)
    print("  -> Creating / verifying client workspace...")
    client = Client.query.filter_by(user_id=client_user.id).first()
    if not client:
        client = Client(
            user_id=client_user.id,
            company_name="AeroFit Activewear",
            industry="Performance Apparel & D2C",
            tier="Growth",
            status="Active",
            website="https://aerofit.store",
            phone="+91 98765 43210",
            address="Cyber City, Tower B, Gurugram, India"
        )
        db.session.add(client)
        db.session.commit()

    # 5. Brand Kit
    brand_kit = BrandKit.query.filter_by(client_id=client.id).first()
    if not brand_kit:
        brand_kit = BrandKit(
            client_id=client.id,
            brand_name="AeroFit Activewear",
            tagline="Engineered for Peak Human Motion",
            target_audience="Fitness enthusiasts, marathoners, and gym goers aged 22-38 in top tier metros",
            primary_color="#FFC72C",
            secondary_color="#EF4444",
            font_family="Inter, sans-serif",
            voice_tone="Energetic, confident, performance-oriented, modern",
            brand_guidelines="Bold headlines, high-contrast imagery, dynamic athletic movement shots."
        )
        db.session.add(brand_kit)

    # 6. Social Accounts
    if SocialAccount.query.filter_by(client_id=client.id).count() == 0:
        print("  -> Seeding connected social media channels...")
        accounts_data = [
            ("Instagram", "@aerofit_official", "AeroFit Official", 42500, 185000, 4.8),
            ("Facebook", "AeroFit Performance Gear", "AeroFit Gear", 28000, 95000, 3.2),
            ("LinkedIn", "AeroFit Technologies", "AeroFit Corp", 8900, 24000, 5.1),
            ("X (Twitter)", "@AeroFitActive", "AeroFit Active", 15200, 62000, 3.9),
            ("YouTube", "AeroFit Training Lab", "AeroFit Lab", 19400, 88000, 6.4)
        ]
        for platform, handle, name, followers, reach, eng in accounts_data:
            db.session.add(SocialAccount(
                client_id=client.id,
                platform=platform,
                account_handle=handle,
                account_name=name,
                is_connected=True,
                follower_count=followers,
                reach_count=reach,
                engagement_rate=eng
            ))
        db.session.commit()

    # 7. Campaigns
    campaign1 = Campaign.query.filter_by(client_id=client.id, name="Diwali Mega Performance Drop").first()
    if not campaign1:
        print("  -> Seeding marketing campaigns...")
        campaign1 = Campaign(
            client_id=client.id,
            name="Diwali Mega Performance Drop",
            objective=CampaignObjective.SALES,
            status=CampaignStatus.ACTIVE,
            budget=450000.0,
            spend=320000.0,
            start_date=date.today() - timedelta(days=20),
            end_date=date.today() + timedelta(days=10),
            target_audience_desc="Urban fitness enthusiasts interested in premium athletic wear",
            platforms_json=["Instagram", "Meta Ads", "Google Search"],
            ai_recommendations_summary="High-converting video carousel ad driving 4.2x ROAS."
        )
        campaign2 = Campaign(
            client_id=client.id,
            name="Q4 Black Friday Warmup",
            objective=CampaignObjective.LEAD_GENERATION,
            status=CampaignStatus.ACTIVE,
            budget=250000.0,
            spend=145000.0,
            start_date=date.today() - timedelta(days=10),
            end_date=date.today() + timedelta(days=20),
            target_audience_desc="Lookalike audience based on past high-value purchasers",
            platforms_json=["Instagram", "YouTube", "Meta Ads"],
            ai_recommendations_summary="Lead capture cost down 28% after testing dynamic hook variations."
        )
        campaign3 = Campaign(
            client_id=client.id,
            name="Summer Runners Tribe Activation",
            objective=CampaignObjective.BRAND_AWARENESS,
            status=CampaignStatus.COMPLETED,
            budget=150000.0,
            spend=150000.0,
            start_date=date.today() - timedelta(days=60),
            end_date=date.today() - timedelta(days=30),
            target_audience_desc="Runners and marathon athletes across Mumbai, Bangalore, Delhi",
            platforms_json=["Instagram", "X (Twitter)"],
            ai_recommendations_summary="Exceeded reach goal by 142%."
        )
        db.session.add_all([campaign1, campaign2, campaign3])
        db.session.commit()

    # 8. 30 Days of Daily Performance Metrics
    if CampaignMetric.query.filter_by(client_id=client.id).count() == 0:
        print("  -> Seeding 30 days of real-time performance analytics...")
        channels = ["Meta Ads", "Google Ads", "Instagram Organic", "YouTube Ads"]
        base_date = date.today() - timedelta(days=30)
        
        for i in range(31):
            cur_date = base_date + timedelta(days=i)
            # Cycle through channels
            for ch in channels:
                if ch == "Meta Ads":
                    spend = 4200.0 + (i * 95)
                    revenue = spend * (3.8 + ((i % 5) * 0.2))
                    impr = 12000 + (i * 350)
                    clicks = int(impr * 0.038)
                    conv = int(clicks * 0.045)
                    reach = int(impr * 0.78)
                elif ch == "Google Ads":
                    spend = 3100.0 + (i * 70)
                    revenue = spend * (4.2 + ((i % 3) * 0.3))
                    impr = 8500 + (i * 220)
                    clicks = int(impr * 0.052)
                    conv = int(clicks * 0.065)
                    reach = int(impr * 0.85)
                elif ch == "YouTube Ads":
                    spend = 2000.0 + (i * 40)
                    revenue = spend * (2.9 + ((i % 4) * 0.25))
                    impr = 15000 + (i * 410)
                    clicks = int(impr * 0.022)
                    conv = int(clicks * 0.028)
                    reach = int(impr * 0.72)
                else: # Organic
                    spend = 0.0
                    revenue = 8500.0 + (i * 280)
                    impr = 9500 + (i * 290)
                    clicks = int(impr * 0.041)
                    conv = int(clicks * 0.035)
                    reach = int(impr * 0.82)

                db.session.add(CampaignMetric(
                    client_id=client.id,
                    campaign_id=campaign1.id if ch in ["Meta Ads", "Google Ads"] else None,
                    date=cur_date,
                    channel=ch,
                    impressions=impr,
                    reach=reach,
                    clicks=clicks,
                    conversions=conv,
                    spend=spend,
                    revenue=revenue
                ))
        db.session.commit()

    # 9. Social Posts
    if SocialPost.query.filter_by(client_id=client.id).count() == 0:
        print("  -> Seeding calendar social posts...")
        posts = [
            SocialPost(
                client_id=client.id,
                platform="Instagram",
                caption="Engineered for athletes who refuse to slow down. The new Pro-Knit 2.0 Breathable Shorts are live. Tap the link in bio to claim your early access drop.",
                hashtags="#AeroFit #PeakMotion #ProKnit #ActiveWearIndia",
                media_type="IMAGE",
                status=PostStatus.PUBLISHED,
                likes=1420,
                comments=88,
                shares=134,
                impressions=38000,
                reach=29500,
                clicks=1240,
                engagement_rate=4.8,
                published_time=datetime.now(timezone.utc) - timedelta(days=2)
            ),
            SocialPost(
                client_id=client.id,
                platform="LinkedIn",
                caption="How we engineered moisture-wicking fabric that weighs 35% less than conventional elastane blends. A deep dive into sustainable textile R&D.",
                hashtags="#TextileInnovation #D2CGrowth #SustainableFashion",
                media_type="ARTICLE",
                status=PostStatus.PUBLISHED,
                likes=412,
                comments=39,
                shares=67,
                impressions=14500,
                reach=11200,
                clicks=520,
                engagement_rate=5.2,
                published_time=datetime.now(timezone.utc) - timedelta(days=4)
            ),
            SocialPost(
                client_id=client.id,
                platform="Instagram",
                caption="Weekend Motivation: You don't get the sweat you don't earn. Step out and conquer the miles today. 🔥",
                hashtags="#SundayRun #AeroFitTribe #MorningMotivation",
                media_type="IMAGE",
                status=PostStatus.SCHEDULED,
                scheduled_time=datetime.now(timezone.utc) + timedelta(days=1, hours=2)
            ),
            SocialPost(
                client_id=client.id,
                platform="X (Twitter)",
                caption="Poll: When's your prime training hour? 5:00 AM Dawn Crew or 8:00 PM Night Owls? Sound off below 👇",
                media_type="TEXT",
                status=PostStatus.SCHEDULED,
                scheduled_time=datetime.now(timezone.utc) + timedelta(days=2, hours=5)
            )
        ]
        db.session.add_all(posts)
        db.session.commit()

    # 10. Leads CRM
    if Lead.query.filter_by(client_id=client.id).count() == 0:
        print("  -> Seeding CRM leads and customer data...")
        leads_data = [
            ("Vikram", "Malhotra", "vikram@fitpulse.co.in", "+91 98111 22334", "FitPulse Gyms Network", "Website Contact", LeadStatus.QUALIFIED, LeadScore.HOT, 92, "Corporate partnership inquiry for 1,200 gym trainer kits."),
            ("Priya", "Sharma", "priya.s@activeliving.org", "+91 98222 33445", "ActiveLiving Studios", "Meta Ad Form", LeadStatus.NEW, LeadScore.HOT, 88, "Requested wholesale catalog for 5 studio outlets."),
            ("Rajesh", "Khanna", "rajesh@delhifitness.com", "+91 98333 44556", "Delhi Fitness Hub", "Direct Inquiry", LeadStatus.CONTACTED, LeadScore.WARM, 74, "Interested in custom co-branded marathon tees."),
            ("Ananya", "Desai", "ananya@yogaverse.life", "+91 98444 55667", "YogaVerse Academy", "LinkedIn B2B", LeadStatus.NEW, LeadScore.WARM, 68, "Requested pricing tier for female athletic gear."),
            ("Rohan", "Gupta", "rohan.g@gmail.com", "+91 98555 66778", "", "Newsletter Signup", LeadStatus.NEW, LeadScore.COLD, 42, "Individual consumer interested in seasonal discounts.")
        ]
        for fn, ln, em, ph, comp, src, stat, score, sval, reason in leads_data:
            lead = Lead(
                client_id=client.id,
                first_name=fn,
                last_name=ln,
                email=em,
                phone=ph,
                company=comp,
                source=src,
                status=stat,
                ai_score=score,
                score_value=sval,
                ai_score_reason=reason
            )
            db.session.add(lead)
        db.session.commit()

        # Seed 2 converted customers with high LTV
        c1 = Customer(
            client_id=client.id,
            name="Suresh Nair",
            email="suresh@apexmarathoners.in",
            phone="+91 98666 77889",
            company="Apex Marathon Club",
            lifetime_value=145000.0,
            orders_count=4,
            status="Active"
        )
        c2 = Customer(
            client_id=client.id,
            name="Kavita Rao",
            email="kavita@velocityathletic.com",
            phone="+91 98777 88990",
            company="Velocity Athletic Centers",
            lifetime_value=88500.0,
            orders_count=2,
            status="Active"
        )
        db.session.add_all([c1, c2])
        db.session.commit()

    # 11. SEO Project & Keywords
    seo_proj = SEOProject.query.filter_by(client_id=client.id).first()
    if not seo_proj:
        print("  -> Seeding SEO audit and tracked keywords...")
        seo_proj = SEOProject(
            client_id=client.id,
            website_url="https://aerofit.store",
            health_score=88,
            technical_score=92,
            content_score=85,
            backlink_score=78,
            organic_traffic_estimate=64500,
            total_keywords=28,
            meta_title="AeroFit Activewear | Premium Performance Athletic Clothing",
            meta_description="Engineered for peak performance. Shop breathable gym shorts, seamless running tees, and compression tights. Free shipping across India.",
            audit_data_json={
                "core_web_vitals": "Passed (LCP 1.4s, CLS 0.02, FID 18ms)",
                "crawl_errors": 0,
                "mobile_friendly": True,
                "schema_markup": "Product, Organization, BreadcrumbList present"
            }
        )
        db.session.add(seo_proj)
        db.session.flush()

        keywords = [
            ("breathable gym shorts for men", 1, 2, 24000, 38, "https://aerofit.store/collections/shorts"),
            ("best compression running tights india", 3, 6, 18200, 44, "https://aerofit.store/collections/tights"),
            ("seamless moisture wicking t-shirt", 2, 5, 14300, 41, "https://aerofit.store/collections/t-shirts"),
            ("performance athletic wear d2c india", 4, 8, 9500, 32, "https://aerofit.store")
        ]
        for kw, cr, pr, vol, diff, url in keywords:
            db.session.add(SEOKeyword(
                project_id=seo_proj.id,
                keyword=kw,
                current_rank=cr,
                previous_rank=pr,
                search_volume=vol,
                difficulty=diff,
                url_target=url
            ))
        db.session.commit()

    # 12. AI Recommendations
    if Recommendation.query.filter_by(client_id=client.id).count() == 0:
        print("  -> Seeding AI marketing recommendations...")
        recs = [
            Recommendation(
                client_id=client.id,
                title="Shift ₹45,000 from Google Display to Instagram Reels Retargeting",
                description="Google Display campaigns have a high CPA of ₹1,420 with 0.8% CTR, while Instagram Reels are converting at ₹310 with 4.8x ROAS. Reallocating budget will yield an estimated +₹165,000 in monthly revenue.",
                category="Budget Optimization",
                priority=RecommendationPriority.HIGH,
                confidence_score=94,
                projected_impact="+₹165,000 Monthly Revenue",
                status=RecommendationStatus.PENDING,
                action_code="REALLOCATE_BUDGET"
            ),
            Recommendation(
                client_id=client.id,
                title="Deploy Automated Abandoned Cart Recovery WhatsApp Flow",
                description="Cart abandonment currently sits at 68%. Adding a 2-step WhatsApp trigger sequence (15 min and 6 hours) recovers an industry average of 18-24% of lost checkouts.",
                category="Retention & CRM",
                priority=RecommendationPriority.CRITICAL,
                confidence_score=96,
                projected_impact="+18% Cart Recovery Rate",
                status=RecommendationStatus.PENDING,
                action_code="ACTIVATE_WHATSAPP_FLOW"
            ),
            Recommendation(
                client_id=client.id,
                title="Publish In-Depth SEO Comparison Guide: 'Merino Wool vs Synthetic Tech-Knit'",
                description="Search volume for tech fabric comparisons spiked +42% in Q3. Ranking top 3 for this intent will attract high-ticket buyers directly into the sales funnel.",
                category="SEO & Content",
                priority=RecommendationPriority.MEDIUM,
                confidence_score=87,
                projected_impact="+8,500 Monthly Organic Visitors",
                status=RecommendationStatus.PENDING,
                action_code="CREATE_SEO_CONTENT"
            )
        ]
        db.session.add_all(recs)
        db.session.commit()

    # 13. Automation Rules
    if AutomationRule.query.filter_by(client_id=client.id).count() == 0:
        print("  -> Seeding automation rules...")
        rules = [
            AutomationRule(
                client_id=client.id,
                name="Auto-Diagnose Engagement Drops > 15%",
                event_trigger="ENGAGEMENT_DROP",
                condition_json={"threshold_percent": 15, "channel": "Instagram"},
                action_type="GENERATE_RECOMMENDATION",
                action_payload_json={"priority": "HIGH", "category": "Social Media"},
                is_active=True
            ),
            AutomationRule(
                client_id=client.id,
                name="Instant Hot Lead Notification",
                event_trigger="HOT_LEAD_CREATED",
                condition_json={"score_threshold": 80},
                action_type="SEND_ALERT",
                action_payload_json={"channels": ["Email", "In-App"]},
                is_active=True
            ),
            AutomationRule(
                client_id=client.id,
                name="Auto-Reallocate Ad Budget on ROAS > 4.5x",
                event_trigger="HIGH_ROAS_DETECTED",
                condition_json={"roas_threshold": 4.5},
                action_type="SCALE_BUDGET",
                action_payload_json={"increase_percent": 20},
                is_active=True
            )
        ]
        db.session.add_all(rules)
        db.session.commit()

    # 14. Notifications
    if Notification.query.filter_by(client_id=client.id).count() == 0:
        db.session.add(Notification(
            client_id=client.id,
            user_id=client_user.id,
            title="Diwali Campaign ROAS Hit 4.2x",
            message="Your 'Diwali Mega Performance Drop' campaign surpassed target ROAS today.",
            type="SUCCESS"
        ))
        db.session.commit()

    print("  [SUCCESS] BACKKBENCHERS Demo Data Seeding Complete!")


if __name__ == "__main__":
    from app import create_app
    app = create_app("development")
    with app.app_context():
        db.create_all()
        run_seed()
